package com.cg.flight;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Flightwreck;
@RequestMapping("api/v1/")
@RestController
@CrossOrigin(origins="*")
public class FlightwreckController {
		@RequestMapping(value="flightwreck", method=RequestMethod.POST)
//		@ResponseBody
		public Flightwreck save(@RequestBody Flightwreck wreck){
			return FlightDetailsStub.create(wreck);
		}
		@RequestMapping(value="flightwrecks",method=RequestMethod.GET)
		public List<Flightwreck> get(){	
			return FlightDetailsStub.list();
		}	
		@RequestMapping(value="flightupdate",method=RequestMethod.PUT)
		public Flightwreck saveAndFlush(@RequestBody Flightwreck wreck) {
			return FlightDetailsStub.update(wreck.getFlightNo(), wreck);	
		}
		@RequestMapping(value="flight/{flightNo}",method=RequestMethod.GET)
		public Flightwreck get(@PathVariable("flightNo") long flightNo ) {
			System.out.println(flightNo);
			return null;	
		}
}
