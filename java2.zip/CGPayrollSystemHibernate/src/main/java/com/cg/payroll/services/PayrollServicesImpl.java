package com.cg.payroll.services;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.daoservices.PayrollDaoServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServiesDownException;

@Component(value="payrollServices")
public class PayrollServicesImpl implements PayrollServices {

	@Autowired
	
	private PayrollDaoServices daoServices;
	public double x;
	public PayrollServicesImpl() throws PayrollServiesDownException{
		daoServices = new PayrollDAOServicesImpl();
	}

	@Override
	public int acceptAssociateDetails(int yearlyInvestmentUnder80C, String firstName, String lastName,
			String department, String designation, String pancard, String emailId, int basicSalary, int epf,
			int companyPf, int accountNo, String bankName, String ifscCode) throws PayrollServiesDownException {
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNo, bankName, ifscCode)));  
	}
	
	@Override
	public int calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException, PayrollServiesDownException{
		Associate associate = this.getAssociateDetails(associateId);
		double basicSalary = associate.getSalary().getBasicSalary();
		associate.getSalary().setPersonalAllowance((int) (0.3 * basicSalary));
		int personalAllowance = associate.getSalary().getPersonalAllowance();
		associate.getSalary().setOtherAllowance((int)(0.1 * basicSalary));
		int otherAllowance=associate.getSalary().getOtherAllowance();
		associate.getSalary().setConveyenceAllowance((int)(0.2 * basicSalary));
		int conveyanceAllowance=associate.getSalary().getConveyenceAllowance();
		associate.getSalary().setHra((int)(0.25 * basicSalary));
		int hra=associate.getSalary().getHra();
		associate.getSalary().setGratuity((int)(0.05 * basicSalary));
		double annualTax=0.0;
		associate.getSalary().setGrossSalary( (int) (basicSalary + personalAllowance + conveyanceAllowance + otherAllowance + hra+  getAssociateDetails(associateId).getSalary().getCompanyPf()));
		int grossSalary = associate.getSalary().getGrossSalary();
		int annualSalary = grossSalary * 12;
		associate.getSalary().setAnnualSalary(annualSalary);
		int nonTaxable = daoServices.getAssociate(associateId).getYearlyInvestmentUnder80C() 
				+ (daoServices.getAssociate(associateId).getSalary().getEpf() 
						+ daoServices.getAssociate(associateId).getSalary().getCompanyPf())*12;
		if(annualSalary>0 && annualSalary<=250000)
			annualTax = 0;
		else if(annualSalary>250000 && annualSalary<=500000){
			if(nonTaxable<150000){
				x = annualSalary - 250000 - nonTaxable;
				annualTax = x*0.1;
			}
			else if(nonTaxable>150000){
				x = annualSalary - 250000 - 150000;
				annualTax = x*0.1;
			}			
		}
		else if(annualSalary>500000 && annualSalary<=1000000){
			if(nonTaxable<150000)
				x = (annualSalary - 250000 - nonTaxable)*0.1;
			else if(nonTaxable>150000)
				x = (annualSalary - 250000 - 150000)*0.1;
			annualTax = x + (annualSalary - 500000)*0.2;
		}
		else if(annualSalary>1000000){
			if(nonTaxable<150000)
				x = (annualSalary - 250000 - nonTaxable)*0.1;
			else if(nonTaxable>150000)
				x = (annualSalary - 250000 - 150000)*0.1;
			annualTax = x + (annualSalary - 500000)*0.2 + (annualSalary - 1000000)*0.3;
		}
		associate.getSalary().setMonthlyTax((int)(annualTax/12));
		int netSalary = grossSalary - associate.getSalary().getMonthlyTax()
				- associate.getSalary().getEpf() - daoServices.getAssociate(associateId).getSalary().getCompanyPf();
		associate.getSalary().setNetSalary(netSalary);
		daoServices.updateAssociate(associate);
		return daoServices.getAssociate(associateId).getSalary().getNetSalary();
	}
	
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException{
		Associate associate = daoServices.getAssociate(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate Details of AssociateId "+associateId+" not found");
		return associate;
	}

	@Override
	public List<Associate> getAllAssociatesDetails() throws PayrollServiesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	
}
