package com.cg.payroll.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.payroll.exceptions.PayrollServiesDownException;



public class PayrollUtilities {
	private static Connection con = null;
	public static Connection getDBConnection() throws PayrollServiesDownException{
		try {
			if(con==null){
				Properties properties = new Properties();
				properties.load(new FileInputStream(new File(".//resource//payrollproperties")));
				Class.forName(properties.getProperty("driver"));
				con = DriverManager.getConnection(properties.getProperty("url"), properties.getProperty("user"), "");
			}
			return con;
		} catch (ClassNotFoundException|IOException|SQLException e) {
			e.printStackTrace();
			throw new PayrollServiesDownException("PayrollServices are down plz try later",e);
		}
	}
}
