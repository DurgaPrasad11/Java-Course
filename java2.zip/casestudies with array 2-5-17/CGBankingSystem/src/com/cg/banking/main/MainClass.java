package com.cg.banking.main;

import java.util.Scanner;

import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServicesImpl banking = new BankingServicesImpl();
		int option;
		do{
			Scanner scanner = new Scanner(System.in);
			System.out.println("Choose an option to perform\n1.Add Customer Details\n2.Add Account Details\n3.Delete record\n4.Search record\n5.Exit");
			option = scanner.nextInt();
			switch (option) {
			case 1:
				banking.acceptCustomerDetails("Durga", "Prasad", "prasad@gmail.com", "4564hsu", "Hyd", "Tgs", 6535, "fsf", "ter", 5615);
				System.out.println(banking.getCustomerDetails(100).getFirstName()+" "+banking.getCustomerDetails(100).getLastName());
				break;
			case 2:

				long acc= banking.openAccount(100, "Savings", 10000);
				//System.out.println(acc);
				System.out.println(banking.getAccountDetails(100, 1000).getAccountBalance());
				break;
			case 3:
				banking.depositAmount(100, 1000, 100);
				System.out.println(banking.getAccountDetails(100, 1000).getAccountBalance());
			default:
				break;
			}
		}while(option!=10);
	}
}
