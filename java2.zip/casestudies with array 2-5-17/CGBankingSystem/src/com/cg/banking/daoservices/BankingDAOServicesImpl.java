package com.cg.banking.daoservices;

import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{
	private static Customer[] customerList = new Customer[10];
	private static Account[] accountList = new Account[10];
	private static int Customer_Id_Counter = 100;
	private static int Account_no = 1000;
	private static int Customer_Id_Index = 0;
	private static int Account_Index = 0;
	private static int Transaction_ID=10;

	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(Customer_Id_Counter++);
		customerList[Customer_Id_Index++]=customer;	
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		
		for(int i=0;i<customerList.length;i++){
			if(customerList[i]!=null&&customerId==customerList[i].getCustomerId()){
				account.setAccountNo(Account_no++);
				customerList[i].getAccounts()[customerList[i].getAccount_Id_Index()]=account;
				customerList[i].setAccount_Id_Index(customerList[i].getAccount_Id_Index()+1);
				
				return customerList[i].getAccounts()[customerList[i].getAccount_Id_Index()-1].getAccountNo();
			}
		}
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerId==customerList[i].getCustomerId())
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j].getAccountNo()==account.getAccountNo()){
						customerList[i].getAccounts()[j]=account;
						return true;
					}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		Random random = new Random();
		get
		return 0;
	}

	@Override
	public long insertTransaction(int customerId, long accountNo, Transaction transaction) {
		for(int i= 0;i<customerList.length;i++)
			if(customerList[i]!=null && customerList[i].getCustomerId()==customerId)
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j].getAccountNo()==accountNo){
						transaction.setTransactionId(Transaction_ID++);
						customerList[i].getAccounts()[j].getTransactions()[customerList[i].getAccounts()[j].getTransaction_ID_Counter()]=transaction;
						customerList[i].getAccounts()[j].setTransaction_ID_Counter(customerList[i].getAccounts()[j].getTransaction_ID_Counter()+1);
						return customerList[i].getAccounts()[j].getTransactions()[customerList[i].getAccounts()[j].getTransaction_ID_Counter()-1].getTransactionId();
					}
		return 0;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId())
				return customerList[i];
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i = 0;i < customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId())
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j].getAccountNo()==accountNo)
				return customerList[i].getAccounts()[j];
		return null;
	}

	@Override
	public Customer[] getCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
