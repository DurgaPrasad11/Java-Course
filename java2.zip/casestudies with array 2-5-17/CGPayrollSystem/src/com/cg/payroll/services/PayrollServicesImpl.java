package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.daoservices.PayrollDaoServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class PayrollServicesImpl implements PayrollServices {

	public PayrollDaoServices daoServices;
	public double x;
	public PayrollServicesImpl(){
		daoServices = new PayrollDAOServicesImpl();
	}


	@Override
	public int acceptAssociateDetails(String firstName, String lastName, 
			String department, String designation, String pancard, String emailId,
			int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNo, String bankName, String ifscCode){
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNo, bankName, ifscCode)));
	}
	/*public int updateAssociateDetails(int associateId, String firstName, String lastName, 
			String department, String designation, String pancard, String emailId,
			int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNo, String bankName, String ifscCode){
		return daoServices.updateAssociate(associate);
	}*/


	@Override
	public int calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException{
		Associate associate = this.getAssociateDetails(associateId);

			double basicSalary = getAssociateDetails(associateId).getSalary().getBasicSalary();
			daoServices.getAssociate(associateId).getSalary().setPersonalAllowance((int) (0.3 * basicSalary));
			int personalAllowance = daoServices.getAssociate(associateId).getSalary().getPersonalAllowance();
			daoServices.getAssociate(associateId).getSalary().setOtherAllowance((int)(0.1 * basicSalary));
			int otherAllowance=daoServices.getAssociate(associateId).getSalary().getOtherAllowance();
			daoServices.getAssociate(associateId).getSalary().setConveyenceAllowance((int)(0.2 * basicSalary));
			int conveyanceAllowance=daoServices.getAssociate(associateId).getSalary().getConveyenceAllowance();
			daoServices.getAssociate(associateId).getSalary().setHra((int)(0.25 * basicSalary));
			int hra=daoServices.getAssociate(associateId).getSalary().getHra();
			daoServices.getAssociate(associateId).getSalary().setGratuity((int)(0.05 * basicSalary));
			int gratuity=daoServices.getAssociate(associateId).getSalary().getGratuity();
			double annualTax=0.0;
			daoServices.getAssociate(associateId).getSalary().setGrossSalary( (int) (basicSalary + personalAllowance + conveyanceAllowance + otherAllowance + hra+  getAssociateDetails(associateId).getSalary().getCompanyPf()));
			int grossSalary = daoServices.getAssociate(associateId).getSalary().getGrossSalary();
			int annualSalary = grossSalary * 12;
			daoServices.getAssociate(associateId).getSalary().setAnnualSalary(annualSalary);
			int yearlyInvestment = daoServices.getAssociate(associateId).getYearlyInvestmentUnder80C();

			int nonTaxable = daoServices.getAssociate(associateId).getYearlyInvestmentUnder80C() 
					+ (daoServices.getAssociate(associateId).getSalary().getEpf() 
					+ daoServices.getAssociate(associateId).getSalary().getCompanyPf())*12;
			if(annualSalary>0 && annualSalary<=250000)
				annualTax = 0;
			else if(annualSalary>250000 && annualSalary<=500000){
				if(nonTaxable<150000){
					x = annualSalary - 250000 - nonTaxable;
					annualTax = x*0.1;
				}
				else if(nonTaxable>150000){
					x = annualSalary - 250000 - 150000;
					annualTax = x*0.1;
				}			
			}
			else if(annualSalary>500000 && annualSalary<=1000000){
				if(nonTaxable<150000)
					x = (annualSalary - 250000 - nonTaxable)*0.1;
				else if(nonTaxable>150000)
					x = (annualSalary - 250000 - 150000)*0.1;
				annualTax = x + (annualSalary - 500000)*0.2;
			}
			else if(annualSalary>1000000){
				if(nonTaxable<150000)
					x = (annualSalary - 250000 - nonTaxable)*0.1;
				else if(nonTaxable>150000)
					x = (annualSalary - 250000 - 150000)*0.1;
				annualTax = x + (annualSalary - 500000)*0.2 + (annualSalary - 1000000)*0.3;
			}
			daoServices.getAssociate(associateId).getSalary().setMonthlyTax((int)(annualTax/12));
			int netSalary = grossSalary - daoServices.getAssociate(associateId).getSalary().getMonthlyTax()
					- daoServices.getAssociate(associateId).getSalary().getEpf() - daoServices.getAssociate(associateId).getSalary().getCompanyPf();
			daoServices.getAssociate(associateId).getSalary().setNetSalary(netSalary);
			return daoServices.getAssociate(associateId).getSalary().getNetSalary();
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException{
		Associate associate = daoServices.getAssociate(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate Details of AssociateId "+associateId+" not found");
		return associate;
	}

	@Override
	public Associate[] getAllAssociatesDetails(){
		return daoServices.getAssociates();
	}
}
