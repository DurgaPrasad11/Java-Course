public class Salary{
	private int basicSalary, hra, conveyenceAllowance,otherAllowance,personalAllowance,monthlyTax, epf, companyPf,gratuity,grossSalary,netSalary;
	public Salary(int basicSalary,int hra,int conveyenceAllowance,int otherAllowance,int personalAllowance,int monthlyTax,int epf,int companyPf,int gratuity,int grossSalary,int netSalary){
		this.basicSalary = basicSalary;
		this.hra = hra;
		this.conveyenceAllowance = conveyenceAllowance;
		this.otherAllowance = otherAllowance;
		this.personalAllowance = personalAllowance;
		this.monthlyTax = monthlyTax;
		this.companyPf = companyPf;
		this.gratuity = gratuity;
		this.grossSalary = grossSalary;
		this.netSalary = netSalary;
	}
	public void setBasicSalary(int basicSalary){
		this.basicSalary = basicSalary;
	}
	public int getBasicSalary(){
		return this.basicSalary;
	}
	public void setHra(int hra){
		this.hra = hra;
	}
	public int getHra(){
		return this.hra;
	}
	public void setConveyenceAllowance(int conveyenceAllowance){
		this.conveyenceAllowance = conveyenceAllowance;
	}
	public int getConveyenceAllowance(){
		return this.conveyenceAllowance;
	}
	public void setOtherAllowance(int otherAllowance){
		this.otherAllowance =otherAllowance;
	}
	public int getOtherAllowance(){
		return this.otherAllowance;
	}
	public void setPersonalAllowance(int personalAllowance){
		this.personalAllowance = personalAllowance;
	}
	public int getPersonalAllowance(){
		return this.personalAllowance;
	}
	public void setMonthlyTax(int monthlyTax){
		this.monthlyTax = monthlyTax;
	}
	public int getMonthlyTax(){
		return this.monthlyTax;
	}
	public void setCompanyPf(int companyPf){
		this.companyPf = companyPf;
	}
	public int getCompanyPf(){
		return this.companyPf;
	}
	public void setGratuity(int gratuity){
		this.gratuity = gratuity;
	}
	public int getGratuity(){
		return this.gratuity ;
	}
	public void setGrossSalary(int grossSalary){
		this.grossSalary = grossSalary;
	}
	public int getGrossSalary(){
		return this.grossSalary; 
	}
	public void setNetSalary(int netSalary){
		this.netSalary = netSalary;
	}
	public int getNetSalary(){
		return this.netSalary ;
	}
}