public class MainClass{
	public static void main(String[] str){
		Associate associate1 = new Associate(123, 20000, "Durga", "Prasad", "ECE", "Analyst", "drgd54676", "dghdf@dfz.com");
		Associate associate2 = new Associate(56, 82642, "Himaja", "rfgs", "CSE", "Associate", "sgs5466", "sdgs@sfg.com");
		Associate associate3 = new Associate(635, 56434, "Priyam", "rgsgs", "EIE", "gsdghdf", "dfhdf645", "wertye@jddf.com");

		BankDetails bankdetails1 = new BankDetails(12345, "HDFC", "ghdrg2005");
		BankDetails bankdetails2 = new BankDetails(65576, "srs", "dsdgsd0635");
		BankDetails bankdetails3 = new BankDetails(75223, "ZCITI", "gjhgh94546");

		Salary salary1 = new Salary(15000,800,567,6464,6462,975,98723,6579,1894,8456,1681);
		Salary salary2 = new Salary(24000,985,6541,968,5196,27,6564,69756,256,6488,9464);
		Salary salary3 = new Salary(30500,4654,8795,54,154,644,157,54545,5458,312,10324);

		System.out.print(" AssociateID: "+associate2.getAssociateID()
							+"\n YearlyInvestmentUnder80C: "+associate2.getYearlyInvestmentUnder80C()
							+"\n FirstName: "+associate2.getFirstName()
							+"\n LastName: "+associate2.getLastName()
							+"\n Department: "+associate2.getDepartment()
							+"\n Designation: "+associate2.getDesignation()
							+"\n PanCard No: "+associate2.getPancard()+"\n EmailId: "+associate2.getEmailId());
		System.out.print("\n Bank Account No: "+bankdetails2.getAccountNumber()
							+"\n BankName: "+bankdetails2.getBankName()
							+"\n IFSC CODE: "+bankdetails2.getIfscCode());
		System.out.print("\n Basic Salary: "+salary2.getBasicSalary()
							+"\n hra:" +salary2.getHra()
							+"\n ConveyenceAllowance: "+salary2.getConveyenceAllowance()
							+"\n OtherAllowances: "+salary2.getOtherAllowance()
							+"\n Personal Allowance: "+salary2.getPersonalAllowance()
							+"\n Monthly Tax: " +salary2.getMonthlyTax()
							+"\n CompanyPf: "+salary2.getCompanyPf()
							+"\n Gratuity: "+salary2.getGratuity()
							+"\n GrossSalary: "+salary2.getGrossSalary()
							+"\n NetSalary: "+salary2.getNetSalary());
	}
}