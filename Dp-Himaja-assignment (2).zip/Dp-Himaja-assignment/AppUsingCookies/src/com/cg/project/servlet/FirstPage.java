package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FirstPage")
public class FirstPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	public void init(ServletConfig config) throws ServletException {
	
	}


	public void destroy() {
		
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("<form name='firstPage' action='SecondPage' method='post'>");
		out.println("<table>");
		out.println("<tr><td>FirstName:-</td>");
		out.println("<td><input type ='text' name='firstName'></td></tr>");
		out.println("<tr><td>LastName:-</td><td><input type ='text' name ='lastName'></td></tr> ");
		out.println("<tr><td><input type ='submit' value ='submit'></td></tr> ");
		out.println("</table></div></body>");
		out.println("</head>");
		out.println("</html>");
	}

}
