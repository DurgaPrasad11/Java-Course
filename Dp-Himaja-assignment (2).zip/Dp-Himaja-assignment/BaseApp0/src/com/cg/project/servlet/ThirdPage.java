package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ThirdPage")
public class ThirdPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		
		out.println("<html>");
		out.println("<head>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("<form name='thirdPage' action='FourthPage' method='post'>");
		out.println("<table>");
		out.println("<font color='green' size='4'>FirstName: </font>"+ firstName+"<br>");
		out.println("<font color='green' size='4'>LastName: </font>"+ lastName+"<br>");
		out.println("<font color='green' size='4'>City: </font>"+ city+"<br>");
		out.println("<font color='green' size='4'>State: </font>"+ state+"<br>");
		out.println("<tr><td>Phone:-</td>");
		out.println("<td><input type ='text' name='phone'></td></tr>");
		out.println("<tr><td>EmailId:-</td><td><input type ='text' name ='emailId'></td></tr> ");
		out.println("<tr><td><input type ='submit' value ='submit'></td></tr> ");
		out.println("</table></div></body>");
		out.println("</head>");
		out.println("</html>");	
	}

}
