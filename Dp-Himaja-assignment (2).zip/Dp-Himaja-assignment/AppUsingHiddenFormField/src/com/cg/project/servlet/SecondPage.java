package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.bean.user;


@WebServlet("/SecondPage")
public class SecondPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//ServletContext context ;
	public void init() throws ServletException {
		//context= getServletContext();
	}

	public void destroy() {
		
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		user user = new user(firstName,lastName);
		ServletContext context = getServletContext();
		context.setAttribute("user", user);
		out.println("<html>");
		out.println("<head>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("<form name='secondPage' action='ThirdPage' method='post'>");
		out.println("<table>");
		out.println("<tr><td>FirstName:<input type='hidden' name='firstName' value="+user.getFirstName()+"></td></tr>");
		out.println("<tr><td>LastName:<input type='hidden' name='firstName' value="+user.getLastName()+"></td></tr>");
		out.println("<tr><td>City:-</td>");
		out.println("<td><input type ='text' name='city'></td></tr>");
		out.println("<tr><td>State:-</td><td><input type ='text' name ='state'></td></tr> ");
		out.println("<tr><td><input type ='submit' value ='submit'></td></tr> ");
		out.println("</table></div></body>");
		out.println("</head>");
		out.println("</html>");	
	}

}
