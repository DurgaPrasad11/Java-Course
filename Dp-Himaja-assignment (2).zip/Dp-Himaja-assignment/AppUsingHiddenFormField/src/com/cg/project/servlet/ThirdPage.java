package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.bean.user;

@WebServlet("/ThirdPage")
public class ThirdPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	public void init() throws ServletException {
		
	}

	public void destroy() {	
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		ServletContext context = getServletContext();
		user user = (user)context.getAttribute("user");
		user.setCity(city);
		user.setState(state);
		context.setAttribute("user", user);
		out.println("<html>");
		out.println("<head>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("<form name='thirdPage' action='FourthPage' method='post'>");
		out.println("<table>");
		//user user1 = (user) context.getAttribute("user");
		out.println("<tr><td>FirstName:<input type='hidden' name='firstName' value="+user.getFirstName()+"></td></tr><br>");
		out.println("<tr><td>LastName:<input type='hidden' name='lastName' value="+user.getLastName()+"></td></tr><br>");
		out.println("<tr><td>City:<input type='hidden' name='city' value="+user.getFirstName()+"></td></tr><br>");
		out.println("<tr><td>State:<input type='hidden' name='state' value="+user.getLastName()+"></td></tr><br>");
		
		out.println("<tr><td>Phone:-</td>");
		out.println("<td><input type ='text' name='phone'></td></tr>");
		out.println("<tr><td>EmailId:-</td><td><input type ='text' name ='emailId'></td></tr> ");
		out.println("<tr><td><input type ='submit' value ='submit'></td></tr> ");
		out.println("</table></div></body>");
		out.println("</head>");
		out.println("</html>");	
	}

}
