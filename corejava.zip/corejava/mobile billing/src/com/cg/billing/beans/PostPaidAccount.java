package com.cg.billing.beans;

public class PostPaidAccount {
	private long mobileNo;
	private plan plan;
	private bill[] bill;

	public PostPaidAccount(long mobileNo, bill[] bill, plan plan) {
		super();
		this.mobileNo = mobileNo;
		this.bill = bill;
		this.plan = plan;
	}

	public plan getPlan() {
		return plan;
	}

	public void setPlan(plan plan) {
		this.plan = plan;
	}

	public bill[] getBill() {
		return bill;
	}

	public void setBill(bill[] bill) {
		this.bill = bill;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	

}
