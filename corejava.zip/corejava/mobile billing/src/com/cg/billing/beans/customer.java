package com.cg.billing.beans;

public class customer {
	private int customerID, mobileNo;
	private String firstName,lastName,dateOfBirth,emailId,adharNo,pancardNo;
	private PostPaidAccount[] PostPaidAccount;
	private address address;
	public customer(int customerID, int mobileNo, String firstName, String lastName, String dateOfBirth, String emailId,
			String adharNo, String pancardNo, PostPaidAccount[] PostPaidAccount, address address) {
		super();
		this.customerID = customerID;
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.emailId = emailId;
		this.adharNo = adharNo;
		this.pancardNo = pancardNo;
		this.PostPaidAccount = PostPaidAccount;
		this.address = address;
	}
	public PostPaidAccount[] getPostPaidAccount() {
		return PostPaidAccount;
	}
	public void setPostPaidAccount(PostPaidAccount[] postPaidAccount) {
		PostPaidAccount = postPaidAccount;
	}
	public address getAddress() {
		return address;
	}
	public void setAddress(address address) {
		this.address = address;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	

}
