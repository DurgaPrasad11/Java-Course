package com.cg.billing.main;

import com.cg.billing.beans.PostPaidAccount;
import com.cg.billing.beans.address;
import com.cg.billing.beans.customer;
import com.cg.billing.beans.plan;

public class MainClass {

	public static void main(String[] args) {
		customer customer1 = new customer(25938, 87468645, "fhgf", "fhs", "11-18-5755", "dfgsdff", "fghfdh56", "fb464");
		customer customer2 = new customer(454788, 55542635, "dghdfh", "hmcxfg", "168-654-216", "iygiugu", "sdfgs56", "sfgs526");
		
		address address1 = new address("fgdf", "dhdf", "6868", "dgsd");
		address address2 = new address("dfhdf", "tyhed", "9386", "tdys");
		
		PostPaidAccount postPaidAccount1 = new PostPaidAccount(9629765954l);
		PostPaidAccount postPaidAccount2 = new PostPaidAccount(7981751761l);
		
		plan plan1 = new plan(468, 4984, 658964, 654868, 34899, 187, 6874, 7988, 245879, 487875, 48989, 499, "fgs", "dghdf");
		plan plan2 = new plan(896, 6866, 946356, 6826, 6841563, 488588, 2148526, 18875, 15778, 263964741, 1789545, 15742689, "tjhtj", "iyyrt");
		System.out.println(customer1.getCustomerID());
		System.out.println(address1.getPinCode() );
		System.out.println(postPaidAccount1.getMobileNo());
	}

}
