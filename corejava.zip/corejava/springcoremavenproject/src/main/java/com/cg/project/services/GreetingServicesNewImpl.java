package com.cg.project.services;

public class GreetingServicesNewImpl implements GreetingServices{
	
	public GreetingServicesNewImpl() {	
		System.out.println("2");
	}

	@Override
	public void sayHello(String personName) {
		System.out.println("Hello"+personName);
		
	}

	@Override
	public void sayBye(String personName) {
		System.out.println("Bye"+personName);
		
	}

}
