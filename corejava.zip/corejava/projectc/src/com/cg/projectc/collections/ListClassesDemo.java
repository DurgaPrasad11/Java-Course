package com.cg.projectc.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.cg.projectc.beans.Customer;

public class ListClassesDemo{
	public static void arrayListClassWork(){
		ArrayList<Customer> customerList = new ArrayList<>();
		//Insert
		customerList.add(new Customer(100, "Durga", "Prasad"));
		customerList.add(new Customer(103, "Himaja", "Adina"));
		customerList.add(new Customer(102, "Satish", "Mahajan"));
		customerList.add(new Customer(110, "Pawan", "konidela"));
		//Iteration
		/*Iterator<Customer>iterator = customerList.iterator();
		while(iterator.hasNext()){
			String string = iterator.next();
		}*/
		//remove
		customerList.remove("Satish");
		
		Collections.sort(customerList);
		Collections.sort(customerList,new customerComparator());
		System.out.println(customerList);
	}

}
