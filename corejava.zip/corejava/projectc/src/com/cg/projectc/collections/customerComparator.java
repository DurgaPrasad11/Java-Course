package com.cg.projectc.collections;

import java.util.Comparator;

import com.cg.projectc.beans.Customer;

public class customerComparator implements Comparator<Customer>{

	@Override
	public int compare(Customer c1, Customer c2) {
		
		return c1.customerId-c2.customerId;
	}

}
