package com.cg.projectc.main;

import java.util.ArrayList;
import java.util.List;

import com.cg.projectc.collections.ListClassesDemo;
import com.cg.projectc.collections.MyGenericType;

public class MainClass {
	public static void main(String[] args) {
		//ListClassesDemo.arrayListClassWork();
		MyGenericType<String> strList = new MyGenericType<String>("Hello", "World");
		MyGenericType<Integer> intList = new MyGenericType<Integer>(122, 1210);
		
		ArrayList<String> strLists = new ArrayList<>();
		strLists.add("abc");
		strLists.add("def");
		strLists.add("ghi");
		iterateOnList(strLists);
		ArrayList<Integer> intLists = new ArrayList<>();
		intLists.add(12);
		intLists.add(45);
		intLists.add(75);
		
		/*for (Integer integer : intLists) {
			System.out.println(integer);
		}*/
			
		}
public static void iterateOnList(List<?> elements){
	for (Object object : elements) {
		System.out.println(object);
	}
}
}