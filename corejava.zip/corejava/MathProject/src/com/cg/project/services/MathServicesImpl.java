package com.cg.project.services;

import com.cg.project.exceptions.InvalidNoRangeException;

public class MathServicesImpl implements MathServices {

	@Override
	public int add(int n1, int n2) throws InvalidNoRangeException {
		if(n1<0) throw new InvalidNoRangeException("Invalid num1");
		if(n2<0) throw new InvalidNoRangeException("Invalid num2");
		int n3 = n1 + n2;
		return n3;
	}

	@Override
	public int sub(int n1, int n2) throws InvalidNoRangeException {
		if(n1<0) throw new InvalidNoRangeException("Invalid num1 in sub");
		if(n2<0) throw new InvalidNoRangeException("Invalid num2 in sub");
		int n3 = n1 - n2;
		return n3;
	}

	@Override
	public int div(int n1, int n2) throws InvalidNoRangeException {
		if(n1<0) throw new InvalidNoRangeException("Invalid num1 in div");
		if(n2<=0) throw new InvalidNoRangeException("Invalid num2 in div");
		int n3 = n1/n2;
		return n3;
	}	
}
