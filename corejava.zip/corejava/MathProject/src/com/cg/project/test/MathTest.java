package com.cg.project.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.exceptions.InvalidNoRangeException;
import com.cg.project.services.MathServices;
import com.cg.project.services.MathServicesImpl;

public class MathTest {
	private static MathServices services;
	private int validNum1, validNum2, inValidNum1, inValidNum2, expectedAns;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		services = new MathServicesImpl();
	}

	@AfterClass
	public static void tearDownAfterClass(){
		services = null;
	}

	@Before
	public void setUpMocckData(){
		validNum1 = 10;
		validNum2 = -20;
		inValidNum1 = -12;
		inValidNum2 = -23;
	}

	@After
	public void tearDownMockData(){
		validNum1 = 10;
		validNum2 = -20;
		inValidNum1 = -12;
		inValidNum2 = -23;
		expectedAns = 0;
	}

	@Test(expected = InvalidNoRangeException.class)
	public void testAddForFirstInvalidNo() throws InvalidNoRangeException {
		services.add(inValidNum1, validNum1);
	}
	@Test(expected = InvalidNoRangeException.class)
	public void testAddForSecondInvalidNo() throws InvalidNoRangeException {
		services.add(validNum1, inValidNum2);
	}
	@Test
	public void testAddForValidNo() throws InvalidNoRangeException {
		Assert.assertEquals(30, services.add(validNum1, validNum2));
	}
	@Test(expected = InvalidNoRangeException.class)
	public void testSubForFirstInvalidNo() throws InvalidNoRangeException {
		services.sub(inValidNum1, validNum1);
	}
	@Test(expected = InvalidNoRangeException.class)
	public void testSubForSecondInvalidNo() throws InvalidNoRangeException {
		services.sub(validNum1, inValidNum2);
	}
	@Test
	public void testSubForValidNo() throws InvalidNoRangeException {
		Assert.assertEquals(-10, services.sub(validNum1, validNum2));
	}
	@Test(expected = InvalidNoRangeException.class)
	public void testDivForFirstInvalidNo() throws InvalidNoRangeException {
		services.div(inValidNum1, validNum1);
	}
	@Test(expected = InvalidNoRangeException.class)
	public void testDivForSecondInvalidNo() throws InvalidNoRangeException {
		services.div(validNum1, inValidNum2);
	}
	@Test
	public void testDivForValidNo() throws InvalidNoRangeException {
		Assert.assertEquals(0, services.div(validNum1, validNum2));
	}
}