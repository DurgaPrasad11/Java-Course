package com.cg.project.client;

import com.cg.project.exceptions.InvalidNoRangeException;
import com.cg.project.services.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InvalidNoRangeException {
		MathServicesImpl service;
		service= new MathServicesImpl();
		System.out.println(service.div(10, 0));	
	}

}
