package com.cg.WebDemo1.driver;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.WebDemo1.LoginPage;

public class LoginPageTest {
	static WebDriver driver;
	private LoginPage loginPage;
	
		@BeforeClass
		public static void setUpDriverEnv(){
			System.setProperty("webdriver.chrome.driver", "D:\\DP-FLP-Java\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
		}
		
		@Before
		public void setUpTestEnv(){
			driver.get("https://github.com/login");
			loginPage = new LoginPage();
			PageFactory.initElements(driver, loginPage);
		}
		
		
		/*@After
		public void destroyTestEnv(){
			loginPage=null;
		}*/
		@Test
		public void testForBlankUserNameAndPassword(){
			loginPage.setUsername("");
			loginPage.setPassword("");
			loginPage.clickSubmitButton();
			String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
			System.out.println("error Message:-"+actualErrorMessage);
			String expectedErrorMessage="Incorrect username or password.";
			Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
		}
		
		@Test
		public void testForInvalidUsername(){
			loginPage.setUsername("DurgaPrad11");
			loginPage.setPassword("Chotu11!!");
			loginPage.clickSubmitButton();
			String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
			System.out.println("error Message:-"+actualErrorMessage);
			String expectedErrorMessage="Incorrect username or password.";
			Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
		}
		@Test
		public void testForInvalidPassword(){
			loginPage.setUsername("DurgaPrad11");
			loginPage.setPassword("Chou11!!");
			loginPage.clickSubmitButton();
			String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
			System.out.println("error Message:-"+actualErrorMessage);
			String expectedErrorMessage="Incorrect username or password.";
			Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
		}
		@Test
		public void testForValidPassword(){
			loginPage.setUsername("DurgaPrasad11");
			loginPage.setPassword("Chotu11!!");
			loginPage.clickSubmitButton();
			String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
			System.out.println("error Message:-"+actualErrorMessage);
			String expectedErrorMessage="Incorrect username or password.";
			Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
			WebElement icon = driver.findElement(By.xpath("//*[@id=\"user-links\"]/li[3]/details/summary/img"));
			icon.click();
		}
		
		
		/*@AfterClass
		public static void destroyDriverEnv(){
			driver.close();
			driver=null;
		}*/
}
