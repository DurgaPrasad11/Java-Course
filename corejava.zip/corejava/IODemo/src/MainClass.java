import java.io.File;
import java.io.IOException;

public class MainClass {

	public static void main(String[] args) {
		try {
			/*File file = new File("d:\\FLPDataFile.txt");
			if(!file.exists())
				file.createNewFile();
			System.out.println(file.length());
			System.out.println(file.canRead());
			System.out.println(file.canWrite());
			System.out.println(file.isFile());*/
			File fromFile =  new File("d:\\FLPDataFile.txt");
			File toFile = new File("d:\\FLPDataFile2.txt");
			ByteStreamDemo.byteReadWriteWork(fromFile, toFile);
			SerializationDemo.doSerialization(fromFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
