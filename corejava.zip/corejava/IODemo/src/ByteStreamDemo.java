import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamDemo {

	public static void byteReadWriteWork(File fromFile, File toFile) throws IOException{
		try(BufferedInputStream src = new BufferedInputStream(new FileInputStream(fromFile))){
			try(BufferedOutputStream dest = new BufferedOutputStream(new FileOutputStream(toFile))){
				//1st way
				int a =0;
				while((a=src.read())!=-1){
					dest.write(a);
				}
				//2nd way
				byte[] dataBuffer = new byte[(int)fromFile.length()];
				src.read(dataBuffer);
				dest.write(dataBuffer);
			}
		}
		/*
		FileInputStream src = new FileInputStream(fromFile);
		FileOutputStream dest = new FileOutputStream(toFile);
		
		//1st way for byte reading
		int a =0;
		while((a=src.read())!=-1)
			src.read();
		//2nd way
		byte[] databuffer = new byte[(int)(fromFile.length())];
		src.read(databuffer);
		System.out.println(new String(databuffer));
		
		//1st way
		while((a=src.read())!=-1)
			dest.write(a);
		//2nd way
		byte[] dataBuffer = new byte[(int)fromFile.length()];
		src.read(dataBuffer);
		dest.write(dataBuffer);
		*/
	}

}
