package com.cg.payroll.main;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDaoServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		PayrollServicesImpl payrollService = new PayrollServicesImpl();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Choose an option to perform\n1.Add record\n2.Update record\n3.Delete record\n4.Search record\n5.Exit");
		int option = scanner.nextInt();
		switch (option) {
		case 1:
			try {
				int associateId1 = payrollService.acceptAssociateDetails("Durga", "Prasad", "ECE", "Analyst", "bshsi458", "prasad@gmail", 150000, 100000, 1000, 1000, 154586, "hasor", "fdgsd");
				int associateId2 = payrollService.acceptAssociateDetails("Himaja", "fdgdf", "cse", "associate", "sfgs454", "sdsgmail.com", 12000, 20000, 120, 540, 4597455, "hdfs", "hdsg545");
				int associateId3 = payrollService.acceptAssociateDetails("Prasad", "fdgdf", "tse", "associate", "ssfgs454", "sdsgmail.com", 10000, 10000, 110, 520, 4397455, "hdfs", "hdsg545");
				int associateId4 = payrollService.acceptAssociateDetails("Uma", "fdgdf", "tse", "associate", "ssfgs454", "sdsgmail.com", 15000, 10000, 140, 520, 4397455, "hdfs", "hdsg545");
				int associateId5 = payrollService.acceptAssociateDetails("Laxmi", "fdgdf", "tse", "associate", "ssfgs454", "sdsgmail.com", 18000, 10000, 140, 520, 4397455, "hdfs", "hdsg545");
				int associateId6 = payrollService.acceptAssociateDetails("Narayana", "fdgdf", "tse", "associate", "ssfgs454", "sdsgmail.com", 11000, 10000, 140, 520, 4397455, "hdfs", "hdsg545");
				int associateId7 = payrollService.acceptAssociateDetails("Uma", "fdgdf", "tse", "associate", "ssfgs454", "sdsgmail.com", 15000, 10000, 140, 520, 4397455, "hdfs", "hdsg545");
				payrollService.calculateNetSalary(111);
				payrollService.calculateNetSalary(112);
				System.out.println(payrollService.getAssociateDetails(111).getFirstName()+" "+payrollService.getAssociateDetails(111).getLastName()+" "+payrollService.getAssociateDetails(111).getSalary().getNetSalary());
				System.out.println(payrollService.getAssociateDetails(112).getFirstName()+" "+payrollService.getAssociateDetails(112).getLastName()+" "+payrollService.getAssociateDetails(112).getSalary().getNetSalary());
				payrollService.daoServices.deleteAssociate(payrollService.getAssociateDetails(111));
				System.out.println(payrollService.getAssociateDetails(111).getFirstName()+" "+payrollService.getAssociateDetails(111).getLastName()+" "+payrollService.getAssociateDetails(111).getSalary().getNetSalary());
				System.out.println(payrollService.getAssociateDetails(113).getFirstName()+" "+payrollService.getAssociateDetails(113).getLastName()+" "+payrollService.getAssociateDetails(113).getSalary().getNetSalary());
				System.out.println(payrollService.getAssociateDetails(114).getFirstName()+" "+payrollService.getAssociateDetails(114).getLastName()+" "+payrollService.getAssociateDetails(114).getSalary().getNetSalary());
				System.out.println(payrollService.getAssociateDetails(115).getFirstName()+" "+payrollService.getAssociateDetails(115).getLastName()+" "+payrollService.getAssociateDetails(115).getSalary().getNetSalary());
				System.out.println(payrollService.getAssociateDetails(116).getFirstName()+" "+payrollService.getAssociateDetails(116).getLastName()+" "+payrollService.getAssociateDetails(116).getSalary().getNetSalary());
				System.out.println(payrollService.getAssociateDetails(117).getFirstName()+" "+payrollService.getAssociateDetails(117).getLastName()+" "+payrollService.getAssociateDetails(117).getSalary().getNetSalary());
			} catch (AssociateDetailsNotFoundException e) {
				e.printStackTrace();
				System.out.println("Asssociate details not found");
			}catch (Exception e){
				e.printStackTrace();
				System.out.println("Asssociate details not found");
			}
			break;
		case 2:
			break;

		default:
			System.out.println("Please enter a valid option");
			break;
		}
		
		
		//System.out.println(payrollService.getAssociateDetails(associateId).getFirstName()+" "+payrollService.getAssociateDetails(associateId).getLastName()+" "+payrollService.getAssociateDetails(associateId).getSalary().getNetSalary());
		
	}
}
		/*String associateNameToBeSearch = "Rajiv";
		Associate associate=searchAssociate(associateNameToBeSearch);
		if (associate!=null)
			System.out.println(associate.getFirstName()+" "+associate.getLastName()+" "+associate.getYearlyInvestmentUnder80C()+" "+associate.getSalary().getBasicSalary());
		else
			System.out.println(associateNameToBeSearch+" not found");
		
	}
public static Associate searchAssociate(String associateNameToBeSearch){
		Associate[] associates = new Associate[5]; 
		associates[0] = new Associate(542, 987741, "Rajiv", "Sharma","Analyst","BGEEGD884E","DFHDFH56456DH","rgxjyjk@gmail.com",new Salary(15000, 5385, 2310, 50, 250, 2500, 310, 124, 220, 25103, 23145));
		associates[1] = new Associate(654, 985543, "Satish", "Shankar","Analyst", "DTHHDT8978D","FJHTFG567DF","rgjkxfjhgjk@gmail.com", new Salary(18000, 25, 652, 1556, 3244, 1442, 3540, 1245, 6952, 4122, 23545));
		associates[2] = new Associate(845, 564534, "Satish", "Iyer","Sr Analyst", "DNDGHN53148J","FGSG4544gssF","rgfjxfgjgjk@gmail.com",new Salary(1000, 5622, 2356, 2546, 25315, 51554, 5423,5544, 5215, 53413, 47864));
		associates[3] = new Associate(545, 121895, "Sonu", "Nigam","Sr Analyst", "SYHGSG468SG","FGRGE564SSG","rgjkxfgjgjk@gmail.com",new Salary(10002, 4652, 14532, 1652, 5165, 563, 563, 4865, 1235, 45896, 1235));
		for(Associate  associate:associates)
			if(associate!=null && associate.getFirstName()==associateNameToBeSearch && associate.getYearlyInvestmentUnder80C()>=987741 && associate.getSalary().getBasicSalary()==15000)
			{
				return associate;
			}
			return null;
		
	}*/
