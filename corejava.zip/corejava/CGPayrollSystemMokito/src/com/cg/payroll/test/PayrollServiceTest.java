package com.cg.payroll.test;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDaoServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServiceTest {
	private static PayrollServices services;
	private static PayrollDaoServices mockDaoServices;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		mockDaoServices=Mockito.mock(PayrollDaoServices.class);
		services=new PayrollServicesImpl(mockDaoServices);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
	}

	@Before
	public void setUp() throws Exception {
		Associate associate1 = new Associate(1001, 10000, "Durga", "Prasad", "Java", "Analyst", "Bsvpb4", "prasad@gmail", new Salary(25000, 250, 150), new BankDetails(12345, "Hdfc", "hdfc0005"));
		Associate associate2 = new Associate(1002, 15000, "Himaja", "Adina", "Mainf", "Associate", "adws15", "himaja@gmail", new Salary(45000, 450, 250), new BankDetails(45612, "CITI", "CITI00544"));
		Associate associate3 = new Associate(15000, "Divya", "Teja", "Mainf", "Analyst", "sfas45", "Divya@gmail", new Salary(30000, 250, 500), new BankDetails(45789, "ICICI", "icici326"));
		Mockito.when(mockDaoServices.getAssociate(1001)).thenReturn(associate1);
		Mockito.when(mockDaoServices.getAssociate(1002)).thenReturn(associate2);
		Mockito.when(mockDaoServices.getAssociate(125)).thenReturn(null);
		ArrayList<Associate> arrayList = new ArrayList<>();
		arrayList.add(associate1);
		arrayList.add(associate2);
		//arrayList.add(associate3);
		//Mockito.when(mockDaoServices.insertAssociate(associate3)).thenReturn(1003);
		Mockito.when(mockDaoServices.getAssociate(1003)).thenReturn(associate3);
	}

	@After
	public void tearDown() throws Exception {
		
	}

	@Test(expected = AssociateDetailsNotFoundException.class)
	public void test() throws Exception {
		int expectedId = 1002;
		Associate associate = new Associate(1002, 15000, "Himaja", "Adina", "Mainf", "Associate", "adws15", "himaja@gmail", new Salary(45000, 450, 250), new BankDetails(45612, "CITI", "CITI00544"));
		//Associate associate = new Associate(15000, "Divya", "Teja", "Mainf", "Analyst", "sfas45", "Divya@gmail", new Salary(30000, 250, 500), new BankDetails(45789, "ICICI", "icici326"));
		Assert.assertEquals(services.getAssociateDetails(1002) ,associate);
		//Mockito.verify(mockDaoServices).getAssociate(1002);
	}
	
	
}
