package com.cg.WebDriverDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverDemo {
	public static void main(String[] args){
		System.setProperty("webdriver.chrome.driver", "D:\\DP-FLP-Java\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		
		WebElement searchField = driver.findElement(By.id("lst-ib"));
		searchField.sendKeys("capgemini");
		searchField.submit();
		
		WebElement imagesLink = driver.findElement(By.linkText("Images"));
		imagesLink.click();
		
		WebElement imageElement = driver.findElements(By.cssSelector("a[class=rg_l]")).get(3);
		imageElement.click();
		//WebElement imageLink = imageElement.findElement(By.tagName("img"));
		//imageLink.click();
	}
}
