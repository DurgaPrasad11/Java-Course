package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.jni.User;

import com.cg.project.beans.UserBean;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(value={"/LoginServlet"},loadOnStartup=1)
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;

	@Override
	public void init(){
		ServletContext servletContext = getServletContext();
		con = (Connection)servletContext.getAttribute("con");
	}

	@Override
	public void destroy() {}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String userName = request.getParameter("userName");
			String password = request.getParameter("password");
			RequestDispatcher dispatcher;
			UserBean userBean = new UserBean(userName, password);
			PreparedStatement pstmt = con.prepareStatement("select password from UserBean where userName=?");
			pstmt.setString(1, userBean.getUserName());
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				if(rs.getString("password").equals(userBean.getPassword())){
					dispatcher = request.getRequestDispatcher("SuccessPage.jsp");
					request.setAttribute("userBean", userBean);
					dispatcher.forward(request, response);
				}
				else{
					dispatcher = request.getRequestDispatcher("ErrorPage.jsp");
					request.setAttribute("errorMessage", "Password is wrong");
					dispatcher.forward(request, response);
				}
			}
			else{
				dispatcher = request.getRequestDispatcher("ErrorPage.jsp");
				request.setAttribute("errorMessage", "Invalid Credentials");
				dispatcher.forward(request, response);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	
	/*protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		RequestDispatcher dispatcher;
		UserBean userBean = new UserBean(userName, password);
		if(userBean.getUserName().equals("Durga")&&userBean.getPassword().equals("sasasasa")){
			dispatcher = request.getRequestDispatcher("SuccessServlet");
			request.setAttribute("userBean", userBean);
			dispatcher.forward(request, response);
		}
		else{
			dispatcher = request.getRequestDispatcher("ErrorServlet");
			request.setAttribute("errorMessage", "Invalid credentials");
			dispatcher.forward(request, response);
		}

		//Another code
		//PrintWriter writer = response.getWriter();
		/*writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		if(username.equals("sasasasa")){
			writer.println("<font color='green' size='2'>Welcome</font>"+" "+username);
		}
		else{
			writer.println("<font color='red' size='10'>login failed</font>");
		}
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
	}*/
}
