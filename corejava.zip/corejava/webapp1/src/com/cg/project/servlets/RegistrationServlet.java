package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;
	
	public void init(ServletConfig config) throws ServletException {
		ServletContext servletContext = getServletContext();
		con = (Connection)servletContext.getAttribute("con");
	}
	
	public void destroy() {}
/*
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("userName");
		String firstname = request.getParameter("firstName");
		String[] communication = request.getParameterValues("communication");
		String graduation = request.getParameter("graduation");
		String description = request.getParameter("description");
		String houseNo = request.getParameter("houseNo");
		String streetName = request.getParameter("streetName");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String pincode = request.getParameter("pincode");
		PrintWriter writer = response.getWriter();

		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("<font color='blue' size='6'>Registration Successful</font><br>");
		writer.println("<font color='green' size='4'>Welcome</font>"+" "+firstname+" "+"<font color='green' size='4'>your username is</font>"+" "+username+"<br>");
		writer.println("<font color='red' size='4'>you chose</font>"+" "+graduation+"<br>");
		writer.println("<font color='red' size='4'>you chose</font>");
		for(int i=0;i<communication.length;i++){
			writer.println(communication[i]);
		}
		writer.println("<br><font color='red' size='4'>project description:</font>"+description);
		writer.println("<font color='violet' size='4'>address</font>"+houseNo+" "+streetName+" "+city+" "+state+" "+pincode);
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
*/
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String userName = request.getParameter("userName");
			String password = request.getParameter("password");
			String password1 = request.getParameter("password1");
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			//String[] communication = request.getParameterValues("communication");
			String graduation = request.getParameter("graduation");
			String description = request.getParameter("description");
			String houseNo = request.getParameter("houseNo");
			String streetName = request.getParameter("streetName");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String pincode = request.getParameter("pincode");
			RequestDispatcher dispatcher;
			UserBean userBean = new UserBean(userName, password, firstName, lastName, graduation, description, houseNo, streetName, city, state, pincode/*,communication*/);
			PreparedStatement pstmt = con.prepareStatement("Insert into userBean (userName, password, firstName, lastName, graduation, description, houseNo, streetName, city, state, pincode value (?,?,?,?,?,?,?,?,?,?,?))");
			if(password.equals(password1)){
				pstmt.setString(1, userBean.getUserName());
				pstmt.setString(2, userBean.getPassword());
				pstmt.setString(3, userBean.getFirstName());
				pstmt.setString(4, userBean.getLastName());
				//pstmt.setString(5, userBean.getCommunication());
				pstmt.setString(5, userBean.getGraduation());
				pstmt.setString(6, userBean.getDescription());
				pstmt.setString(7, userBean.getHouseNo());
				pstmt.setString(8, userBean.getStreetName());
				pstmt.setString(9, userBean.getCity());
				pstmt.setString(10, userBean.getState());
				pstmt.setString(11, userBean.getPincode());
				ResultSet rs = pstmt.executeQuery();
				dispatcher = request.getRequestDispatcher("LoginPage.jsp");
				request.setAttribute("userBean", userBean);
				dispatcher.forward(request, response);
			}
			
			//doGet(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
