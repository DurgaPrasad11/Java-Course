package com.cg.payroll.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.Associate;
@Component(value="payrollDaoServices")
public class PayrollDAOServicesImpl implements PayrollDaoServices {

	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;

	@Override
	public int insertAssociate(Associate associate) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate.getAssociateID();
	}

	@Override
	public Associate updateAssociate(Associate associate) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.getTransaction().commit();
		entityManager.close();
		
		return associate;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Associate a2= entityManager.find(Associate.class, associateId);
		entityManager.remove(a2);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}

	@Override
	public Associate getAssociate(int associateID) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Associate.class, associateID);
		
	}

	public List<Associate> getAssociates() {
		// TODO Auto-generated method stub
		return null;
	}

}
