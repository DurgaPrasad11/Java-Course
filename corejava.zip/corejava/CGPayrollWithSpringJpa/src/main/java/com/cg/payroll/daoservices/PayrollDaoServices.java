package com.cg.payroll.daoservices;
import java.sql.SQLException;
import java.util.List;
import com.cg.payroll.beans.Associate;
public interface PayrollDaoServices {
	int insertAssociate(Associate associate) ;
	//boolean updateAssociate(Associate associate); 
	boolean deleteAssociate(int associateId) ;
	Associate getAssociate(int associateID) ;
	List<Associate> getAssociates() ;
	Associate updateAssociate(Associate associate);
}