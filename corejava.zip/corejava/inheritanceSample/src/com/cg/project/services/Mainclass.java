package com.cg.project.services;

public class Mainclass {
	MathServices MathServices = new MathServicesImpl();
	

}
