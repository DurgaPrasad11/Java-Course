package com.cg.project.services;

public class MathServicesImpl implements MathServices {
	

	@Override
	public int add(int n1, int n2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int sub(int n1, int n2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int div(int n1, int n2) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
	
	
	
}
