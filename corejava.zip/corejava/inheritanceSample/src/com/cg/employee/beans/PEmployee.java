package com.cg.employee.beans;

public class PEmployee extends Employee{
	private int hra, ta, da;

	public PEmployee() {
		super();	
	}
	
	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}

	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName,int hra, int ta, int da) {
		super();
		this.hra = hra;
		this.ta = ta;
		this.da = da;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}
	
	public void calculateSalary(){
		this.hra = 30*this.getBasicSalary()/100;
		this.ta = 20*this.getBasicSalary()/100;
		this.da = 5*this.getBasicSalary()/100;
		this.setTotalSalary(hra + ta + da + getBasicSalary());
		//super.calculateSalary();
	}

	@Override
	public String toString() {
		return super.toString()+"hra=" + hra + ", ta=" + ta + ", da=" + da;
	}

}
