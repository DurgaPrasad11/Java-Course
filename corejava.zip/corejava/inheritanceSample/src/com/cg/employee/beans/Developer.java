package com.cg.employee.beans;

public final class Developer extends PEmployee{
	private int incentive;

	public Developer() {
		super();
	}

	public Developer(int employeeId, int basicSalary, String firstName, String lastName, int incentive) {
		super(employeeId, basicSalary, firstName, lastName);
		this.incentive = incentive;
	}

	public int getIncentive() {
		return incentive;
	}

	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}
	public void calculateSalary(){
		super.calculateSalary();
		setTotalSalary(incentive + getTotalSalary());
	}
	
	@Override
	public String toString() {
		return super.toString()+"incentive=" + incentive;
	}
	
}
