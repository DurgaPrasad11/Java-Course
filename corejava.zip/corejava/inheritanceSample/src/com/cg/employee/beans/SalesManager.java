package com.cg.employee.beans;

public final class SalesManager extends PEmployee{
	private int commission, salesAmt;

	public SalesManager() {
		super();
	}

	public SalesManager(int employeeId, int basicSalary, String firstName, String lastName, int salesAmt) {
		super(employeeId, basicSalary, firstName, lastName);
		this.salesAmt = salesAmt;
		
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}

	public int getSalesAmt() {
		return salesAmt;
	}

	public void setSalesAmt(int salesAmt) {
		this.salesAmt = salesAmt;
	}
	
	public void calculateSalary(){
		super.calculateSalary();
		this.commission = getSalesAmt()/100;
		setTotalSalary(commission + super.getTotalSalary());
	}
	public void doASale(){
		System.out.println("sales done");
	}
	@Override
	public String toString() {
		return super.toString()+"commission=" + getCommission() + ", salesAmt=" + getSalesAmt();
	}
	
	
}
