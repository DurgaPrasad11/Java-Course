package com.cg.employee.main;

import com.cg.employee.beans.Developer;
import com.cg.employee.beans.Employee;
import com.cg.employee.beans.PEmployee;
import com.cg.employee.beans.SalesManager;

public class MainClass {

	public static void main(String[] args) {
	/*	Employee employee = new Employee(110, 15000, "Durga", "Prasad");
		employee.calculateSalary();
		System.out.println(employee.toString()); */
		Employee employee;
		employee = new PEmployee(112, 151000, "Durga", "Prasad");
		employee.calculateSalary();
		System.out.println(employee.toString());
		
		PEmployee pEmployee = new PEmployee(111, 19000, "anish", "keshav");
		pEmployee.calculateSalary();
		System.out.println(pEmployee.toString());
		
		SalesManager salesManager = new SalesManager(1113, 15000, "Durga", "Prasad", 1000);
		salesManager.calculateSalary();
		//salesManager.doASale();
		System.out.println(salesManager.toString());
		
		Developer developer = new Developer(1114, 10000, "Durga", "Prasad", 150);
		developer.calculateSalary();
		System.out.println(developer.toString());
		
		Employee employee2 = new SalesManager(115, 15000, "Himaja", "Adina", 1000);
		SalesManager sm = (SalesManager) employee2;
		sm.doASale();
		sm.calculateSalary();
		System.out.println(sm.toString());
	}
}
