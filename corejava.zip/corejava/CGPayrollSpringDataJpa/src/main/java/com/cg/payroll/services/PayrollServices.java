package com.cg.payroll.services;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServiesDownException;
public interface PayrollServices{
	int acceptAssociateDetails( int yearlyInvestmentUnder80C, String firstName, String lastName, String department, 
			String designation, String pancard, String emailId, int basicSalary, int epf, int companyPf, int accountNo,
			String bankName, String ifscCode) throws PayrollServiesDownException;
	int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException, PayrollServiesDownException;
	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException;
	List<Associate> getAllAssociatesDetails() throws PayrollServiesDownException;
	//boolean updateAssociateDetails(Associate associate);
	Associate updateAssociateDetails(int associateId, int yearlyInvestmentUnder80C, String firstName, String lastName, String department, 
			String designation, String pancard, String emailId, int basicSalary, int epf, int companyPf, int accountNo,
			String bankName, String ifscCode) throws AssociateDetailsNotFoundException;
	Boolean deleteAssociate(int  associateId);
	
}