package com.cg.payroll.main;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServiesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException {
		try {
			ApplicationContext applicationContext = new ClassPathXmlApplicationContext("projectbeans.xml");
			PayrollServices payrollServices = (PayrollServices) applicationContext.getBean("payrollServices");		
		payrollServices.acceptAssociateDetails(120000, "dug", "him", "sf", "analyst", "aswr123", "djgey", 123459, 1200, 1200, 1234, "ag", "stfa123");
		payrollServices.acceptAssociateDetails(10000, "dfg", "yikh", "htj", "ttgyjh", "rtrth", "rth", 5463568, 56863, 1200, 1234, "ag", "stfa123");
		//System.out.println(payrollServices.getAssociateDetails(1));
		//Associate a1=payrollServices.getAssociateDetails(1);
		//System.out.println(payrollServices.updateAssociateDetails(3,15000, "durga", "prasad", "java", "analyst", "vcs1223", "prasad@gmail.com", 30000, 300, 200, 12345, "hdfc", "hdfc00050"));
		//System.out.println(a1);
		//System.out.println(payrollServices.getAssociateDetails(1));
		payrollServices.calculateNetSalary(2);
		payrollServices.deleteAssociate(1);
		//System.out.println(a1);
		
	
		} catch (BeansException e) {
		  e.printStackTrace();
		} catch (PayrollServiesDownException e) {
			e.printStackTrace();
		}
		
	}
}