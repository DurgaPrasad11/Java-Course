package com.cg.payroll.exceptions;

public class PayrollServiesDownException extends Exception{

	public PayrollServiesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PayrollServiesDownException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PayrollServiesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PayrollServiesDownException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PayrollServiesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
