package com.cg.payroll.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.daoservices.PayrollDaoServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utilities.PayrollUtilities;

public class PayrollServiceTest {
	private static PayrollServices services;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		services = new PayrollServicesImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		services = null;
	}

	@Before
	public void setUp() throws Exception {
		Associate associate1 =  new Associate(PayrollUtilities.ASSOCIATE_ID_COUNTER++,15000, "Durga", "prasad", "Java", "Analyst", "BS584", "prasad@gmail", new Salary(20000, 250, 200), new BankDetails(12244, "Sbi", "sbi123"));
		Associate associate2 =  new Associate(PayrollUtilities.ASSOCIATE_ID_COUNTER++,20000, "Himaja", "Adina", "Mainf", "Analyst1", "BS5584", "himaja@gmail", new Salary(40000, 250, 200), new BankDetails(13244, "Sbi", "sbi4123"));
		Associate associate3 =  new Associate(PayrollUtilities.ASSOCIATE_ID_COUNTER++,10000, "abcd", "def", "abc", "Analyst2", "BS5845", "abc@gmail", new Salary(30000, 450, 400), new BankDetails(12544, "Sbi", "sbi1234"));
		PayrollDAOServicesImpl.associates.put(associate1.getAssociateID(), associate1);
		PayrollDAOServicesImpl.associates.put(associate2.getAssociateID(), associate2);
		PayrollDAOServicesImpl.associates.put(associate3.getAssociateID(), associate3);
		System.out.println(PayrollDAOServicesImpl.associates);
	}

	@After
	public void tearDown() throws Exception {
		PayrollUtilities.ASSOCIATE_ID_COUNTER=111;
		PayrollDAOServicesImpl.associates.clear();
	}

	@Test
	public void test() {
		int expectedAssociateId = 114;
		Associate actualAssociate = new Associate(PayrollUtilities.ASSOCIATE_ID_COUNTER++,1000, "a", "b", "C", "e", "d123", "ab@gmail", new Salary(10000, 100, 150), new BankDetails(12345, "abd", "avbd42"));
		Assert.assertEquals(expectedAssociateId, actualAssociate.getAssociateID());
	}
	@Test
	public void testForObject() throws AssociateDetailsNotFoundException{
		Associate expectedAssociate = new Associate(113,10000, "abcd", "def", "abc", "Analyst2", "BS5845", "abc@gmail", new Salary(30000, 450, 400), new BankDetails(12544, "Sbi", "sbi1234"));
		Associate associate5=services.getAssociateDetails(113);
		Assert.assertEquals(expectedAssociate, associate5);
	}

}
