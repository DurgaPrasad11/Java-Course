package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.utilities.PayrollUtilities;
public class PayrollDAOServicesImpl implements PayrollDaoServices {
	public static HashMap<Integer,Associate> associates = new HashMap<>();
	
	@Override
	public int insertAssociate(Associate associate) {
		associate.setAssociateID(PayrollUtilities.ASSOCIATE_ID_COUNTER++);
		associates.put(associate.getAssociateID(), associate);
		return associate.getAssociateID();
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		associates.put(associate.getAssociateID(), associate);
		return false;
	}
	@Override
	public boolean deleteAssociate(Associate associate) {
		associates.remove(associate.getAssociateID());
		return false;
	}

	@Override
	public Associate getAssociate(int associateID) {
		return associates.get(associateID);
	}

	@Override
	public List<Associate> getAssociates() {
		return new ArrayList<>(associates.values());
	}
}