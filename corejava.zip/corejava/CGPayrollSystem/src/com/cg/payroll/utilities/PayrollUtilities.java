package com.cg.payroll.utilities;

public class PayrollUtilities {
	public static int ASSOCIATE_ID_COUNTER =111;
}
