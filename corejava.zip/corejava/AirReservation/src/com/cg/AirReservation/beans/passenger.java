package com.cg.AirReservation.beans;

public class passenger {
	private String name;
	private int mobileNo;
	private journeyDetails[] journeyDetails;
	public passenger(String name, int mobileNo, com.cg.AirReservation.beans.journeyDetails[] journeyDetails) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.journeyDetails = journeyDetails;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public journeyDetails[] getJourneyDetails() {
		return journeyDetails;
	}
	public void setJourneyDetails(journeyDetails[] journeyDetails) {
		this.journeyDetails = journeyDetails;
	}	
}
