package com.cg.AirReservation.beans;

public class flight {
	private String fname, fnum;
	private ticket ticket;
	public flight(String fname, String fnum, com.cg.AirReservation.beans.ticket ticket) {
		super();
		this.fname = fname;
		this.fnum = fnum;
		this.ticket = ticket;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getFnum() {
		return fnum;
	}
	public void setFnum(String fnum) {
		this.fnum = fnum;
	}
	public ticket getTicket() {
		return ticket;
	}
	public void setTicket(ticket ticket) {
		this.ticket = ticket;
	}
	
}
