package com.cg.AirReservation.beans;

public class journeyDetails {
	private String from, to, doj;
	private flight[] flight;
	public journeyDetails(String from, String to, String doj, com.cg.AirReservation.beans.flight[] flight) {
		super();
		this.from = from;
		this.to = to;
		this.doj = doj;
		this.flight = flight;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public flight[] getFlight() {
		return flight;
	}
	public void setFlight(flight[] flight) {
		this.flight = flight;
	}
	
}
