package com.cg.TrainReservation.beans;

public class train {
		private String fname, fnum;
		private ticket ticket;
		public train(String fname, String fnum, com.cg.TrainReservation.beans.ticket ticket) {
			super();
			this.fname = fname;
			this.fnum = fnum;
			this.ticket = ticket;
		}
		public String getFname() {
			return fname;
		}
		public void setFname(String fname) {
			this.fname = fname;
		}
		public String getFnum() {
			return fnum;
		}
		public void setFnum(String fnum) {
			this.fnum = fnum;
		}
		public ticket getTicket() {
			return ticket;
		}
		public void setTicket(ticket ticket) {
			this.ticket = ticket;
		}
		

}
