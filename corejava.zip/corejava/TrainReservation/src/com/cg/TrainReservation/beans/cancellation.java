package com.cg.TrainReservation.beans;

public class cancellation {
	private String status;
	private int totalFare, cancellationFee, refund;
	public cancellation(String status, int totalFare, int cancellationFee, int refund) {
		super();
		this.status = status;
		this.totalFare = totalFare;
		this.cancellationFee = cancellationFee;
		this.refund = refund;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(int totalFare) {
		this.totalFare = totalFare;
	}
	public int getCancellationFee() {
		return cancellationFee;
	}
	public void setCancellationFee(int cancellationFee) {
		this.cancellationFee = cancellationFee;
	}
	public int getRefund() {
		return refund;
	}
	public void setRefund(int refund) {
		this.refund = refund;
	}
}
