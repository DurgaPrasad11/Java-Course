package com.cg.TrainReservation.beans;

public class transaction {
	private String transactionStatus;
	private int baseFare, tax, totalFare;
	public transaction(String transactionStatus, int baseFare, int tax, int totalFare) {
		super();
		this.transactionStatus = transactionStatus;
		this.baseFare = baseFare;
		this.tax = tax;
		this.totalFare = totalFare;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public int getBaseFare() {
		return baseFare;
	}
	public void setBaseFare(int baseFare) {
		this.baseFare = baseFare;
	}
	public int getTax() {
		return tax;
	}
	public void setTax(int tax) {
		this.tax = tax;
	}
	public int getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(int totalFare) {
		this.totalFare = totalFare;
	}
	
	
}
