package com.cg.TrainReservation.beans;

public class ticket {
	private String timeOfDep, timeOfArr;
	private int seatnum;
	private transaction transaction;
	private cancellation cancellation;
	public ticket(String timeOfDep, String timeOfArr, int seatnum,
			com.cg.TrainReservation.beans.transaction transaction,
			com.cg.TrainReservation.beans.cancellation cancellation) {
		super();
		this.timeOfDep = timeOfDep;
		this.timeOfArr = timeOfArr;
		this.seatnum = seatnum;
		this.transaction = transaction;
		this.cancellation = cancellation;
	}
	public String getTimeOfDep() {
		return timeOfDep;
	}
	public void setTimeOfDep(String timeOfDep) {
		this.timeOfDep = timeOfDep;
	}
	public String getTimeOfArr() {
		return timeOfArr;
	}
	public void setTimeOfArr(String timeOfArr) {
		this.timeOfArr = timeOfArr;
	}
	public int getSeatnum() {
		return seatnum;
	}
	public void setSeatnum(int seatnum) {
		this.seatnum = seatnum;
	}
	public transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(transaction transaction) {
		this.transaction = transaction;
	}
	public cancellation getCancellation() {
		return cancellation;
	}
	public void setCancellation(cancellation cancellation) {
		this.cancellation = cancellation;
	}
	
}
