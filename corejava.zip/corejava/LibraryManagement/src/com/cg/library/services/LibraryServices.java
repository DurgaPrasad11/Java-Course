package com.cg.library.services;

public interface LibraryServices {
	int acceptUserDetails(int mobileNo, String name);
	int acceptBookDetails()
}
