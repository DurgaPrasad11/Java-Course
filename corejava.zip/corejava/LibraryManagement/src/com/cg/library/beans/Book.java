package com.cg.library.beans;

import java.util.HashMap;

public class Book {
	private int totalNoOfBooks;
	private String bookName;
	private HashMap<Integer, BookDetails> bookDetails = new HashMap<>();
	public Book(int totalNoOfBooks, String bookName, HashMap<Integer, BookDetails> bookDetails) {
		super();
		this.totalNoOfBooks = totalNoOfBooks;
		this.bookName = bookName;
		this.bookDetails = bookDetails;
	}
	
}
