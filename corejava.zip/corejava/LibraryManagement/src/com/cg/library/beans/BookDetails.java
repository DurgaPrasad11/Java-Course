package com.cg.library.beans;

import java.text.SimpleDateFormat;

public class BookDetails {
	private int bookId;
	private SimpleDateFormat issueDate, dueDate;
	private String issueStatus;
	public BookDetails(SimpleDateFormat issueDate, SimpleDateFormat dueDate, String issueStatus) {
		super();
		this.issueDate = issueDate;
		this.dueDate = dueDate;
		this.issueStatus = issueStatus;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public SimpleDateFormat getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(SimpleDateFormat issueDate) {
		this.issueDate = issueDate;
	}
	public SimpleDateFormat getDueDate() {
		return dueDate;
	}
	public void setDueDate(SimpleDateFormat dueDate) {
		this.dueDate = dueDate;
	}
	public String getIssueStatus() {
		return issueStatus;
	}
	public void setIssueStatus(String issueStatus) {
		this.issueStatus = issueStatus;
	}
	@Override
	public String toString() {
		return "BookDetails [bookId=" + bookId + ", issueDate=" + issueDate + ", dueDate=" + dueDate + ", issueStatus="
				+ issueStatus + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bookId;
		result = prime * result + ((dueDate == null) ? 0 : dueDate.hashCode());
		result = prime * result + ((issueDate == null) ? 0 : issueDate.hashCode());
		result = prime * result + ((issueStatus == null) ? 0 : issueStatus.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookDetails other = (BookDetails) obj;
		if (bookId != other.bookId)
			return false;
		if (dueDate == null) {
			if (other.dueDate != null)
				return false;
		} else if (!dueDate.equals(other.dueDate))
			return false;
		if (issueDate == null) {
			if (other.issueDate != null)
				return false;
		} else if (!issueDate.equals(other.issueDate))
			return false;
		if (issueStatus == null) {
			if (other.issueStatus != null)
				return false;
		} else if (!issueStatus.equals(other.issueStatus))
			return false;
		return true;
	}
	

}
