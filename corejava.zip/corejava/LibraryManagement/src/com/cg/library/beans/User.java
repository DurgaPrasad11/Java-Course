package com.cg.library.beans;

import java.util.HashMap;

public class User {
	private int userId, mobileNo, noOfBooksIssued;
	private String name;
	public User(int mobileNo, int noOfBooksIssued, String name) {
		super();
		this.mobileNo = mobileNo;
		this.noOfBooksIssued = noOfBooksIssued;
		this.name = name;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getNoOfBooksIssued() {
		return noOfBooksIssued;
	}
	public void setNoOfBooksIssued(int noOfBooksIssued) {
		this.noOfBooksIssued = noOfBooksIssued;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", mobileNo=" + mobileNo + ", noOfBooksIssued=" + noOfBooksIssued + ", name="
				+ name + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mobileNo;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + noOfBooksIssued;
		result = prime * result + userId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (mobileNo != other.mobileNo)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (noOfBooksIssued != other.noOfBooksIssued)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}
	
}
