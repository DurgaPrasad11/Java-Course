package com.cg.project.main;

import com.cg.project.beans.CEmployee;
import com.cg.project.beans.Developer;
import com.cg.project.beans.Employee;
import com.cg.project.beans.PEmployee;
import com.cg.project.beans.SalesManager;
import com.cg.project.collections.ListClassesDemo;

public class MAinClass {

	public static void main(String[] args) {
		/*Employee employee=new Employee("abhi", "ch", 1234, 150000);
		employee.calculateTotalSalary();
		System.out.println(employee.toString());
		
		PEmployee pEmployee=new PEmployee("yosh", "a", 1235, 160000);
		pEmployee.calculateTotalSalary();
		System.out.println(pEmployee.toString());
		
		CEmployee cEmployee=new CEmployee("vijay", "a", 1236, 600);
		cEmployee.contractSign();
		cEmployee.calculateTotalSalary();
		System.out.println(cEmployee.toString());
		
		Developer developer=new Developer("abhinav", "chikoti", 1237, 200000, 3);
		developer.projectsDone();
		developer.calculateTotalSalary();
		System.out.println(developer.toString());
		
		SalesManager salesmanager=new SalesManager("akash", "gupta", 1238, 250000, 36000);
		salesmanager.doASale();
		salesmanager.calculateTotalSalary();
		System.out.println(salesmanager.toString());*/
		ListClassesDemo.arrayListClassWork();
		

	}

}
