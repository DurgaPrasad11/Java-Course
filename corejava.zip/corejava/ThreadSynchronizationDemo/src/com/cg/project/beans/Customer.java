package com.cg.project.beans;

public class Customer implements Runnable{
	public Customer() {}
	private static Account account;
	static{
		account = new Account(10000);
		System.out.println("Initial Balance : "+account.getBalance());
	}
	@Override
	public void run() {
		Thread customerThread = Thread.currentThread();

		if(customerThread.getName().equals("Durga")){
			for(int i=1;i<=10;i++){
				try{
					Thread.sleep(0);
					System.out.println("\nDurga has call withdraw() "+i+" time balance = "+account.withdraw(3000));
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		}
		if(customerThread.getName().equals("Prasad")){
			for(int i=1;i<=10;i++){
				try{
					Thread.sleep(0);
					System.out.println("\nPrasad has call deposit() "+i+" time balance = "+account.deposit(3000));
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		}
		if(customerThread.getName().equals("Himaja")){
			for(int i=1;i<=10;i++){
				try{
					Thread.sleep(0);
					System.out.println("\nHimaja has call getbalance() "+i+" time balance = "+account.getBalance());
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		}
	}
	

}
