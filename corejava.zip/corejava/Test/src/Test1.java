
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Hello");
		
		String s="123";
		int i= Integer.parseInt(s);
		System.out.println("Value i ==> "+i);
	}

}
