package com.cg.banking.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;

public class MainClass {
	public static void main(String[] args) throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bankingServices = (BankingServices) applicationContext.getBean("bankingServices");
		bankingServices.acceptCustomerDetails("fghgfhj", "jghkh", "hsdu", "454fegd", "jhgb", "fgdghc", 46679);
		bankingServices.openAccount(1, "savings", 10000);
		bankingServices.openAccount(1, "current", 250000);
		System.out.println(bankingServices.getAccountDetails(1, 2));
		bankingServices.depositAmount(1, 2, 250);
		bankingServices.depositAmount(1, 2, 350);
		System.out.println(bankingServices.getAccountDetails(1, 2));
	}
}		

