package com.cg.banking.main;

import com.cg.banking.beans.account;
import com.cg.banking.beans.address;
import com.cg.banking.beans.customer;
import com.cg.banking.beans.transaction;

public class MainClass {

	public static void main(String[] args) {
		customer customer1 = new customer(12345, 456354, hkjklol, uygggjj, 155125, ikhihi, dcd545, jh545, uifyfd, account);
		customer customer2 = new customer(454788, 55542635, "dghdfh", "hmcxfg", "168-654-216", "iygiugu", "sdfgs56", "sfgs526");
		
		//address address1 = new address("fgdf", "dhdf", "6868", "dgsd");
		//address address2 = new address("dfhdf", "tyhed", "9386", "tdys");
		
		//account account1 = new account(9668, 66168, "sasf");
		//account account2 =  new account(96492, 245356, "fdgadgr");
		
		transaction transaction1 = new transaction(6898, 6985466, 67643, "ugjikt", "fgsfgs", "dhs", "ryhsrg");
		transaction transaction2 = new transaction(9846, 4168654, 56456, "sdgsdg", "fsdfg", "sdgsdg", "woeuq");
		System.out.println("COSTUMER ID"+customer1.getCustomerID());
		System.out.println("Adress"+address2.getPinCode());
		System.out.println("transcation"+transaction1.getModeOfTransation());
	}
}
