package com.cg.banking.beans;

public class account {
	private int accountNo, accountBalance;
	private String accountType;
	private transaction[] transaction;
	public account(int accountNo, int accountBalance, String accountType, transaction[] transaction) {
		super();
		this.accountNo = accountNo;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.transaction = transaction;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public transaction[] getTransaction() {
		return transaction;
	}
	public void setTransaction(transaction[] transaction) {
		this.transaction = transaction;
	}
}
