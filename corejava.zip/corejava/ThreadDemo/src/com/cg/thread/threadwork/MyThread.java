package com.cg.thread.threadwork;

public class MyThread extends Thread{

	public MyThread() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyThread( String name) {
		super( name);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run(){
		if (this.getName().equals("thread-1")){
			for(int i=0;i<100;i++){
				if(i%2==0)
					System.out.println(i);
			}
		}
		else if(this.getName().equals("thread-0")){
			for(int i=0;i<100;i++)
				if(i%2!=0)
					System.out.println(i);
		}
	
	}

}
