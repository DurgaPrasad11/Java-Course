package com.cg.thread.main;

import com.cg.thread.threadwork.MyThread;
import com.cg.thread.threadwork.RunnableResource;

public class MainClass {

	public static void main(String[] args) {
		RunnableResource resource = new RunnableResource();
		Thread th1 = new Thread(resource, "thread-0");
		Thread th2 = new Thread(resource, "thread-1");
		th1.start();
		th2.start();
		
		/*MyThread th1 = new MyThread("thread-0");
		MyThread th2 = new MyThread("thread-1");
		th1.start();
		th2.start();*/
	}

}
