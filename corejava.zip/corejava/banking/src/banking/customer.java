package banking;

public class customer {

}
