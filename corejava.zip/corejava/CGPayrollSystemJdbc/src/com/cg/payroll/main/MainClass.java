package com.cg.payroll.main;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServiesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException {
		try {
			ApplicationContext applicationContext = new ClassPathXmlApplicationContext("projectbeans.xml");
			PayrollServices payrollServices = (PayrollServices) applicationContext.getBean("payrollServices");
			PayrollServicesImpl payrollServicesImpl= new PayrollServicesImpl();
			payrollServicesImpl.acceptAssociateDetails("Durga", "Prasad", "java", "ass", "sdf343", "sdf", 50000, 100000, 100, 200, 12345, "xcv", "rty");
			System.out.println(payrollServicesImpl.getAssociateDetails(100));
			System.out.println(payrollServices);
		} catch (BeansException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PayrollServiesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}