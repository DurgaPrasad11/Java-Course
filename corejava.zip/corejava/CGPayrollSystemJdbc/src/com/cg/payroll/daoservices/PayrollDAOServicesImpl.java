package com.cg.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.PayrollServiesDownException;
import com.cg.payroll.utilities.PayrollUtilities;

@Component(value="payrollDaoServices")
public class PayrollDAOServicesImpl implements PayrollDaoServices {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		return jdbcTemplate.update("INSERT INTO Associate (yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId value(?,?,?,?,?,?,?)", associate.getYearlyInvestmentUnder80C(),
				associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId());
		/*return jdbcTemplate.update("INSERT INTO Associate (firstName, lastName, department, designation, pancard, emailId, yearlyInvestmentUnder80C, basicSalary, epf, companyPf, accountNo, bankName, ifscCode) values(?,?,?,?,?,?,?,?,?,?,?,?,?)",
				associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getPancard(),associate.getEmailId(),associate.getYearlyInvestmentUnder80C(),associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),
				associate.getSalary().getCompanyPf(),associate.getBankDetails().getAccountNo(),associate.getBankDetails().getBankName(),associate.getBankDetails().getIfscCode());*/
		
		
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAssociate(Associate associate) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Associate getAssociate(int associateID) throws SQLException {
		
		return null ;
	}

	@Override
	public String getName(int associateID) {
		String sql = "SELECT associateId,firstName FROM table WHERE ID=?";
		return sql;
	}
	@Override
	public List<Associate> getAssociates() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	} 

}
/* using jdbc alone
private Connection con =null;
public PayrollDAOServicesImpl() throws PayrollServiesDownException {
	con = PayrollUtilities.getDBConnection();
}

@Override
public int insertAssociate(Associate associate) throws SQLException {
	try{
		con.setAutoCommit(false);
		PreparedStatement pstmt1 = con.prepareStatement("insert into associate (yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId value(?,?,?,?,?,?,?)");
		pstmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
		pstmt1.setString(2, associate.getFirstName());
		pstmt1.setString(3, associate.getLastName());
		pstmt1.setString(4, associate.getDepartment());
		pstmt1.setString(5, associate.getDesignation());
		pstmt1.setString(6, associate.getPancard());
		pstmt1.setString(7, associate.getEmailId());
		pstmt1.executeUpdate();

		PreparedStatement pstmt2 = con.prepareStatement("select max(associateId) from associate");
		ResultSet rs = pstmt2.executeQuery();
		rs.next();
		int associateId = rs.getInt(1);

		PreparedStatement pstmt3 = con.prepareStatement("insert into salary(associateId, basicSalary, epf, companyPf) value(?,?,?)");
		pstmt3.setInt(1, associateId);
		pstmt3.setInt(2, associate.getSalary().getBasicSalary());
		pstmt3.setInt(3, associate.getSalary().getEpf());
		pstmt3.setInt(4, associate.getSalary().getCompanyPf());
		pstmt3.executeUpdate();

		PreparedStatement pstmt4 = con.prepareStatement("insert into bankDetails(associateId, accountNo, bankName, ifscCode) value(?,?,?,?)");
		pstmt4.setInt(1, associateId);
		pstmt4.setInt(2, associate.getBankDetails().getAccountNo());
		pstmt4.setString(3, associate.getBankDetails().getBankName());
		pstmt4.setString(4, associate.getBankDetails().getIfscCode());
		pstmt4.executeUpdate();

		con.commit();
		return associateId;
	}catch (SQLException e) {
		con.rollback();
		throw e;
	}
	finally {
		con.setAutoCommit(true);
	}
}

@Override
public boolean updateAssociate(Associate associate) throws SQLException {
	try{
		con.setAutoCommit(false);
		PreparedStatement pstmt1 = con.prepareStatement("update into associate set yearlyInvestmentUnder80C = ?, firstName = ?, lastName = ? , department = ?, designation = ?, pancard = ?, emailId = ?");
		pstmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
		pstmt1.setString(2, associate.getFirstName());
		pstmt1.setString(3, associate.getLastName());
		pstmt1.setString(4, associate.getDepartment());
		pstmt1.setString(5, associate.getDesignation());
		pstmt1.setString(6, associate.getPancard());
		pstmt1.setString(7, associate.getEmailId());
		pstmt1.executeUpdate();
		//other code start
		PreparedStatement pstmt2 = con.prepareStatement("select max(associateId) from associate");
		ResultSet rs = pstmt2.executeQuery();
		rs.next();
		int associateId = rs.getInt(1);
		//other code finish
		PreparedStatement pstmt3 = con.prepareStatement("update into salary set basicSalary = ?, epf = ?, companyPf = ?");
		pstmt3.setInt(1, associate.getSalary().getBasicSalary());
		pstmt3.setInt(2, associate.getSalary().getEpf());
		pstmt3.setInt(3, associate.getSalary().getCompanyPf());
		pstmt3.executeUpdate();

		PreparedStatement pstmt4 = con.prepareStatement("update into bankDetails set accountNo = ?, bankName = ?, ifscCode = ?");
		pstmt4.setInt(1, associate.getBankDetails().getAccountNo());
		pstmt4.setString(2, associate.getBankDetails().getBankName());
		pstmt4.setString(3, associate.getBankDetails().getIfscCode());
		pstmt4.executeUpdate();

		con.commit();
		return true;
	}catch (SQLException e) {
		con.rollback();
		throw e;
	}
	finally {
		con.setAutoCommit(true);
	}
}

@Override
public boolean deleteAssociate(Associate associate) {
	// TODO Auto-generated method stub
	return false;
}

@Override
public Associate getAssociate(int associateID) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<Associate> getAssociates() {
	// TODO Auto-generated method stub
	return null;
}*/
