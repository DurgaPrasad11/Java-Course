package com.cg.payroll.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServiesDownException;
import com.cg.payroll.services.PayrollServices;

@Controller
public class LoginController {
	
	@Autowired
	PayrollServices payrollServices;
	@RequestMapping(value="/authUser")
	public String authUser(@Valid @ModelAttribute("associate")Associate associate ,BindingResult result) throws AssociateDetailsNotFoundException, PayrollServiesDownException{
		if(result.hasFieldErrors("associateID")|| result.hasFieldErrors("password"))return "loginPage";
		else if(payrollServices.loginAccess(associate.getAssociateID(), associate.getPassword()))
			return "registrationSuccessPage";
			else return "errorPage";
	}
}
