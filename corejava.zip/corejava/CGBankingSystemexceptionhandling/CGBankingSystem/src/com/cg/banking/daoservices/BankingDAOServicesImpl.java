package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.CustomerNotFoundException;


@Component("bankingDaoServices")
public class BankingDAOServicesImpl implements BankingDAOServices {

	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;
	
	@Override
	public int insertCustomer(Customer customer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account)
			throws AccountBlockedException, CustomerNotFoundException {
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction)
			throws AccountBlockedException, CustomerNotFoundException {
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) throws CustomerNotFoundException {
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException {
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) throws CustomerNotFoundException {
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {

		return null;
	}

	@Override
	public List<Customer> getCustomers() {

		return null;
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return null;
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {

		return null;
	}

	@Override
	public float balanceEnquiry(int customerId, long accountNo, int pinNumber) {
		return 0;
	}

}
