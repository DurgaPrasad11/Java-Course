package com.cg.banking.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.services.BankingServices;

public class MainClass {
	public static void main(String[] args) throws BankingServicesDownException {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bankingServices = (BankingServices) applicationContext.getBean("bankingServices");
		bankingServices.acceptCustomerDetails("Durga", "prasad", "durga@gmail", "acs112", "pune", "mh", 4552, "hyd", "ts", 5000);
	}
}		

