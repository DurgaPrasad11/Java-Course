package com.cg.banking.beans;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Customer {
	@Id
	private int customerId;
	private String firstName,lastName,emailId,panCard;
	
	@ElementCollection
	private List<Address> addresses ;
	
	//private Account [] accounts=new Account[10];
	@OneToMany(mappedBy="customer")
	Map<Long, Account> accounts=new HashMap<>();

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	public Map<Long, Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(Map<Long, Account> accounts) {
		this.accounts = accounts;
	}
	
	
}