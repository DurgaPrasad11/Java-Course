package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {

	public BankingDAOServices daoServices;
	public BankingServicesImpl() {
		daoServices = new BankingDAOServicesImpl();
	}
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		return daoServices.insertCustomer(new Customer(firstName, lastName, customerEmailId, panCard, 
				new Address(localAddressPinCode, localAddressCity, localAddressState),new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	}
	@Override
	public long openAccount(int customerId, String accountType, float initBalance) 
			throws InvalidAmountException,
			CustomerNotFoundException,
			InvalidAccountTypeException,
			BankingServicesDownException{
		if(getCustomerDetails(customerId)==null) throw new CustomerNotFoundException("Customer Id: "+customerId+" not found");
		if(!accountType.equals("savings") && !accountType.equals("current")) throw new InvalidAccountTypeException("invalid account type");
		if(initBalance==0) throw new InvalidAmountException("invalid account balance");
		return daoServices.insertAccount(customerId, new Account("savings", "active", initBalance));
	}
	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,AccountNotFoundException,
	BankingServicesDownException, AccountBlockedException {
		if(getAccountDetails(customerId, accountNo).getStatus().equals("blocked")) throw new AccountBlockedException("Account is blocked");
		if(getCustomerDetails(customerId)==null) throw new CustomerNotFoundException("Customer Id not found");
		if(getAccountDetails(customerId, accountNo)==null) throw new AccountNotFoundException("Account No not found");
		daoServices.insertTransaction(customerId, accountNo, new Transaction(amount, "Deposit"));
		Account account = daoServices.getAccount(customerId, accountNo);
		float Amount1 = account.getAccountBalance();
		account.setAccountBalance(Amount1+amount);
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber) throws InsufficientAmountException,CustomerNotFoundException,
	AccountNotFoundException,InvalidPinNumberException,
	BankingServicesDownException ,AccountBlockedException{
		if(getCustomerDetails(customerId)==null) throw new CustomerNotFoundException("Customer Id not found");
		if(getAccountDetails(customerId, accountNo)==null) throw new AccountNotFoundException("Account No not found");
		if(getAccountDetails(customerId, accountNo).getStatus().equals("blocked")) throw new AccountBlockedException("Account is blocked");
		if(getAccountDetails(customerId, accountNo).getPinNumber()==0000) throw new InvalidPinNumberException("Invalid pin");
		if(amount>getAccountDetails(customerId, accountNo).getAccountBalance()) throw new InsufficientAmountException("Insufficient amount in account");
		daoServices.insertTransaction(customerId, accountNo, new Transaction(amount, "Withdrawl"));
		Account account = daoServices.getAccount(customerId, accountNo);
		if(account.getPinNumber()==pinNumber)
		{
			float Amount1 = account.getAccountBalance();
			if(amount<Amount1){
				account.setAccountBalance(Amount1-amount);
				return account.getAccountBalance();
			}
		}
		else
		{
			System.out.println("Wrong pin number");
			account.setPinCounter(account.getPinCounter()+1);
			if(account.getPinCounter()==3){
				account.setStatus("Blocked");
				if(account.getPinCounter()>4)
					System.out.println("Cannot access account");
			}
		}
		return 0;
	}
	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException,
	CustomerNotFoundException,
	AccountNotFoundException,InvalidPinNumberException,
	BankingServicesDownException, AccountBlockedException {
		if(transferAmount>getAccountDetails(customerIdFrom, accountNoFrom).getAccountBalance()) throw new InsufficientAmountException("Insufficient amount");
		if(getCustomerDetails(customerIdFrom)==null || getCustomerDetails(customerIdTo)==null) throw new CustomerNotFoundException("Customer Id not found");
		if(getAccountDetails(customerIdFrom, accountNoFrom)==null || getAccountDetails(customerIdTo, accountNoTo)==null) throw new AccountNotFoundException("Account No not found");
		if(getAccountDetails(customerIdFrom, accountNoFrom).getStatus().equals("blocked") || getAccountDetails(customerIdTo,accountNoTo).getStatus().equals("blocked")) throw new AccountBlockedException("Account is blocked");
		if(getAccountDetails(customerIdFrom, accountNoFrom).getPinNumber()!=pinNumber) throw new InvalidPinNumberException("Invalid pin");
		if(pinNumber==getAccountDetails(customerIdFrom, accountNoFrom).getPinNumber()){
			float bal1 = getAccountDetails(customerIdTo, accountNoTo).getAccountBalance();
			getAccountDetails(customerIdTo, accountNoTo).setAccountBalance(bal1+transferAmount);
			float bal2 = getAccountDetails(customerIdFrom, accountNoFrom).getAccountBalance();
			getAccountDetails(customerIdFrom, accountNoFrom).setAccountBalance(bal2-transferAmount);
			return true;
		}
		return false;

	}
	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException,BankingServicesDownException{
		//if(getCustomerDetails(customerId)==null) throw new CustomerNotFoundException("Customer Id not found");
		return daoServices.getCustomer(customerId);
	}
	@Override
	public Account getAccountDetails(int customerId, long accountNo) throws 
	CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException{
		if(getCustomerDetails(customerId)==null) throw new CustomerNotFoundException("Customer Id not found");
		if(daoServices.getAccount(customerId, accountNo)==null) throw new AccountNotFoundException("Account No not found");
		if(!daoServices.getAccount(customerId, accountNo).getStatus().equals("Blocked"))
		return daoServices.getAccount(customerId, accountNo);
		else
		{
			//System.out.println("Account blocked");
			return daoServices.getAccount(customerId, accountNo);
		}
	}
	@Override
	public int generateNewPin(int customerId, long accountNo) throws
	CustomerNotFoundException,AccountNotFoundException ,
	BankingServicesDownException{
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber) throws CustomerNotFoundException,
	AccountNotFoundException,
	InvalidPinNumberException,BankingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException{

		return daoServices.getCustomers();
	}
	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId) 
			throws BankingServicesDownException,CustomerNotFoundException {
		if(getCustomerDetails(customerId)==null) throw new CustomerNotFoundException("Customer Id not found");
		return daoServices.getAccounts(customerId);
	}
	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo) throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException{
		if(getCustomerDetails(customerId)==null) throw new CustomerNotFoundException("Customer Id not found");
		if(getAccountDetails(customerId, accountNo)==null) throw new AccountNotFoundException("Account No not found");
		return daoServices.getTransactions(customerId, accountNo);
	}
	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException, AccountBlockedException{
		if(getAccountDetails(customerId, accountNo).getStatus().equals("blocked")) throw new AccountBlockedException("Account is blocked");
		if(getCustomerDetails(customerId)==null) throw new CustomerNotFoundException("Customer Id not found");
		if(getAccountDetails(customerId, accountNo)==null) throw new AccountNotFoundException("Account No not found");
		return getAccountDetails(customerId, accountNo).getStatus();
	}
}
