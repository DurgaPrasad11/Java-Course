package com.cg.banking.utilities;

public class BankingUtilities {
	public static int CUSTOMER_ID_COUNTER = 111;
	public static long ACCOUNT_NO_COUNTER = 11111;
	public static long TRANSACTION_ID = 1111;
}
