package com.cg.banking.main;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServicesImpl banking = new BankingServicesImpl();
		int option=0;
		do{
			Scanner scanner = new Scanner(System.in);
			
			try {
				System.out.println("Choose an option to perform\n1.Add Customer Details \n2.Add Account Details\n3.Deposit Amount\n4.Withdraw amount\n5.Display details\n6.Fund Transfer");
				option = scanner.nextInt();
				switch (option) {
				case 1:
					banking.acceptCustomerDetails("Durga", "Prasad", "prasad@gmail.com", "4564hsu", "Hyd", "Tgs", 6535, "fsf", "ter", 5615);
					banking.acceptCustomerDetails("Himaja", "Adina", "prasad@gmail.com", "4564hsu", "Hyd", "Tgs", 6535, "fsf", "ter", 5615);
					System.out.println(banking.getCustomerDetails(111).getFirstName()+" "+banking.getCustomerDetails(111).getLastName()+banking.getCustomerDetails(111).getCustomerId());
					break;
				case 2:

					banking.openAccount(111, "savings", 10000);
					System.out.println("gy");
					//long ac = banking.openAccount(112, "savings", 10000);
					//long acc1= banking.openAccount(111, "abc", 15000);
					//long acc3= banking.openAccount(112, "savings", 2000000);
					//banking.getAccountDetails(112, 11112).setStatus("blocked");
					System.out.println(banking.getAccountDetails(111, 11111));
					//long acc1= banking.openAccount(111, "abc", 15000);
					//System.out.println(banking.getAccountDetails(111, acc1));
					
					break;
				case 3:
					banking.depositAmount(112, 11112, 100);
					System.out.println(banking.getAccountDetails(112, 11112).getAccountBalance());
					break;
				case 4:
					banking.withdrawAmount(111, 11111, 20, 1234);
					System.out.println(banking.getAccountDetails(111, 11111).getStatus());
					break;
				case 5:
					//for (Customer customer : banking.getAllCustomerDetails())
						//System.out.println(customer);
					for (Account account : banking.getcustomerAllAccountDetails(111)) 
						System.out.println(account);
					//for (Transaction transaction : banking.getAccountAllTransaction(111, 11111)) {
						//System.out.println(transaction);
					//}
				case 6:
					banking.fundTransfer(111,11111, 112, 11113, 5000, banking.getAccountDetails(112, 11113).getPinNumber());
					System.out.println(banking.getAccountDetails(111, 11111).getAccountBalance());
					System.out.println(banking.getAccountDetails(112, 11113).getAccountBalance());
				default:
					break;
				}
			} catch (CustomerNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (BankingServicesDownException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (AccountNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (AccountBlockedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InsufficientAmountException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidPinNumberException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidAmountException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidAccountTypeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}while(option!=10);
	}
}
