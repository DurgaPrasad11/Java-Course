package com.cg.banking.test;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.omg.CORBA.PUBLIC_MEMBER;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utilities.BankingUtilities;

public class BankingTest {
	private static BankingServices services;
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		services = new BankingServicesImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		services=null;
	}

	@Before
	public void setUp() throws Exception {
		BankingUtilities.CUSTOMER_ID_COUNTER=111;
		BankingUtilities.ACCOUNT_NO_COUNTER=11111;
		//Customer customer = new Customer(BankingUtilities.CUSTOMER_ID_COUNTER++,"sf", "lastName", "emailId", "panCard", new Address(115, "Hyd", "Ts"), new Address(116, "asf", "afp"));
		HashMap<Long, Account> account =new HashMap<>();
		HashMap<Long, Account> account2 =new HashMap<>();
		Account acc = new Account("savings", "active", 10000);
		//Customer customer2 = new Customer(BankingUtilities.CUSTOMER_ID_COUNTER++, "Durga", "Prasad", "prasad.durga", "bscjh978", new Address(1256, "hyd", "Ts"), new Address(1452, "yfgd", "tsio"), account.put(BankingUtilities.ACCOUNT_NO_COUNTER,account.get(BankingUtilities.ACCOUNT_NO_COUNTER++)));
		Customer customer2 = new Customer(BankingUtilities.CUSTOMER_ID_COUNTER, "Durga", "Prasad", "prasad.durga", "bscjh978", new Address(1256, "hyd", "Ts"), new Address(1452, "yfgd", "tsio"), account);
		acc.setAccountNo(BankingUtilities.ACCOUNT_NO_COUNTER);
		account.put(BankingUtilities.ACCOUNT_NO_COUNTER, acc);
		BankingDAOServicesImpl.customers.put(BankingUtilities.CUSTOMER_ID_COUNTER++, customer2);
	}

	@After
	public void tearDown() throws Exception {
	BankingDAOServicesImpl.customers.clear();
	BankingUtilities.CUSTOMER_ID_COUNTER=111;
	BankingUtilities.ACCOUNT_NO_COUNTER=11111;
	}

	@Test
	public void test() throws CustomerNotFoundException, BankingServicesDownException {
		HashMap<Long, Account> account =new HashMap<>();
		Account acc = new Account("savings", "active", 10000);
		Customer actual = new Customer(111, "Durga", "Prasad", "prasad.durga", "bscjh978", new Address(1256, "hyd", "Ts"), new Address(1452, "yfgd", "tsio"), account);
		acc.setAccountNo(BankingUtilities.ACCOUNT_NO_COUNTER);
		account.put(BankingUtilities.ACCOUNT_NO_COUNTER, acc);
		Customer expected = services.getCustomerDetails(111);
		
		System.out.println(expected);
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
	}

}
