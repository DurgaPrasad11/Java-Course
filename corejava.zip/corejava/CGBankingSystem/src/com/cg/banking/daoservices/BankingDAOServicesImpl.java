package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utilities.BankingUtilities;

public class BankingDAOServicesImpl implements BankingDAOServices{
	public static HashMap<Integer, Customer> customers = new HashMap<>();
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(BankingUtilities.CUSTOMER_ID_COUNTER++);
		customers.put(customer.getCustomerId(), customer);
		//System.out.println(customers.get(customer.getCustomerId()));
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(BankingUtilities.ACCOUNT_NO_COUNTER++);
		customers.get(customerId).getAccounts().put(account.getAccountNo(), account);
		account.setPinCounter(0);
		generatePin(customerId, account);
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		customers.get(customerId).getAccounts().put(account.getAccountNo(), account);
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		Random random = new Random();
		account.setPinNumber(random.nextInt(1000));
		return account.getPinNumber();
	}

	@Override
	public long insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingUtilities.TRANSACTION_ID++);
		Account account = customers.get(customerId).getAccounts().get(accountNo);
		account.getTransactions().put(transaction.getTransactionId(), transaction);
		return transaction.getTransactionId();
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		customers.get(customerId).getAccounts().remove(accountNo);
		return true;
	}

	@Override
	public Customer getCustomer(int customerId) {
		//if(customers.get(customerId)!=null)
		return customers.get(customerId);
		//return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		
		return customers.get(customerId).getAccounts().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		return  new ArrayList<Customer>(customers.values());
		
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList<Account>(customers.get(customerId).getAccounts().values());
		
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		List<Transaction> transactions = new ArrayList<Transaction>(customers.get(customerId).getAccounts().get(accountNo).getTransactions().values());
		return transactions;
	}
	
}
