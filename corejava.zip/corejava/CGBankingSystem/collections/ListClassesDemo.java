package com.cg.project.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ListClassesDemo {
	public static void arrayListClassWork(){
		ArrayList<String> strList = new ArrayList<>();
		//Insert
		strList.add("Satish");
		strList.add("Durga");
		strList.add("prasad");
		strList.add("Himaja");
		//Iteration
		Iterator<String>iterator = strList.iterator();
		while(iterator.hasNext()){
			String string = iterator.next();
		}
		//remove
		strList.remove("Satish");
		
		Collections.sort(strList);
	}

}
