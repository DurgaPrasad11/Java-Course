package com.cg.payroll.daoservices;
import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.Associate;
@Component(value="payrollDaoServices")
public class PayrollDAOServicesImpl implements PayrollDaoServices {

	@Autowired(required=true)
	private SessionFactory sessionFactory;

	@Override
	public int insertAssociate(Associate associate) {
		Session session=sessionFactory.openSession();
		int id=(int) session.save(associate);
		session.flush();
		return id;
		/*Session session = sessionFactory.openSession();
		Transaction tx=null;
		tx=session.beginTransaction();
		int associateid= (int) session.save(associate);
		tx.commit();
		//session.getTransaction().commit();
		session.close();
		//sessionFactory.close();
		return associateid;*/
		/*Session session=sessionFactory.openSession();
        Transaction tx=session.beginTransaction();
        try {
        Integer associateId= (Integer) session.save(associate);
        tx.commit();
        return associateId;
        } catch (HibernateException e) {
        tx.rollback();
        e.printStackTrace();
        throw e;
        }
        finally{
            session.close();
        }*/
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		Session session = sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(associate);
		session.getTransaction().commit();
		session.close();
		return true;
	}

	@Override
	public Associate getAssociate(int associateID) {
		return (Associate) sessionFactory.openSession().get(Associate.class, associateID);
	}

	public List<Associate> getAssociates() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
		Session session = sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(getAssociate(associateId));
		session.getTransaction().commit();
		session.close();
		return true;
	}

}
